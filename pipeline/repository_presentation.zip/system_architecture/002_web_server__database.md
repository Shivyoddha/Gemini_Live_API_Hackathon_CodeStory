### Slide 2: Web Server & Database
- **Web Server:** Puma is utilized for serving web requests, known for its performance and multi-threaded capabilities.
- **Database:** MySQL is the chosen relational database management system for storing application data persistently.