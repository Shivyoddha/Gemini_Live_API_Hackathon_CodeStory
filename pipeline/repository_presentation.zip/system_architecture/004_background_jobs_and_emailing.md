### Slide 4: Background Jobs and Emailing
- **Active Job:** Basic configurations for Active Job are present, suggesting a foundation for background processing if needed.
- **Action Mailer:** The application includes Action Mailer for sending transactional emails, such as confirmations or notifications.