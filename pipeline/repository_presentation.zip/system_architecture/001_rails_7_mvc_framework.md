### Slide 1: Rails 7 MVC Framework
- The application is built using the Ruby on Rails 7 framework, adhering to the Model-View-Controller (MVC) architectural pattern.
- Leverages standard Rails components such as ActiveRecord for database interactions and Action Mailer for email functionality.