### Slide 2: Technology Stack - Frontend & Backend
- **Backend:** Ruby on Rails 7, Puma web server, MySQL database.
- **Frontend:** HTML, CSS, JavaScript, Bootstrap for styling, Hotwire (Turbo & Stimulus) for dynamic interactions.
- **Asset Management:** jsbundling-rails (esbuild) and cssbundling-rails (Sass).