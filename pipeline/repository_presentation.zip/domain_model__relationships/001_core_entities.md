### Slide 1: Core Entities
- **User:** Represents the application's end-users.
- **Company:** Represents travel service providers.
- **Trippackage:** Represents available travel packages.
- **Slot:** Represents a specific booking or time slot for a travel package.
- **Feedback:** Represents user reviews and ratings for companies.