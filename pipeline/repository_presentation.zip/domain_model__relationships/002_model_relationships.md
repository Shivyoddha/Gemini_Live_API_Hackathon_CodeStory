### Slide 2: Model Relationships
- **User** `has_many` `Slots` and `has_many` `Feedbacks`.
- **Company** `has_many` `Trippackages` and `has_many` `Feedbacks`.
- **Trippackage** `has_many` `Slots` and `belongs_to` `Company`.
- **Slot** `belongs_to` `User` and `belongs_to` `Trippackage`.
- **Feedback** `belongs_to` `User` and `belongs_to` `Company`.