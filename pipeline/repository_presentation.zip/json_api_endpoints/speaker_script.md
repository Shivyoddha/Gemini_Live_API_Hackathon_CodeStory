## JSON API Endpoints

### Slide 1: API Accessibility
To support potential integrations and advanced frontend functionalities, the Traveller application exposes JSON API endpoints for its primary resources. This allows external applications or services to programmatically interact with the application's data in a structured format.

### Slide 2: Available API Endpoints
The application provides JSON API endpoints for the following key resources:
- `/companies`
- `/feedbacks`
- `/slots`
- `/trippackages`
These endpoints are meticulously crafted using the `jbuilder` gem, ensuring efficient and clean JSON serialization. This makes it straightforward for developers to consume the application's data externally.