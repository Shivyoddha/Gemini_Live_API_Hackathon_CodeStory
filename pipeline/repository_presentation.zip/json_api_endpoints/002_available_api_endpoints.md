### Slide 2: Available API Endpoints
- Endpoints are provided for:
    - `companies`
    - `feedbacks`
    - `slots`
    - `trippackages`
- These endpoints enable programmatic access to application data, supporting potential integrations or advanced frontend interactions.