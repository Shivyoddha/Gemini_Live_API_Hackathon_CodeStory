### Slide 1: HTML, CSS, and JavaScript Foundation
- The frontend is built using standard web technologies: HTML for structure, CSS for styling, and JavaScript for interactivity.
- Bootstrap is utilized for a responsive and consistent user interface.