## Frontend Architecture

### Slide 1: HTML, CSS, and JavaScript Foundation
The foundation of Traveller's frontend architecture rests on the standard trio of web technologies: HTML for structuring content, CSS for styling and presentation, and JavaScript for interactivity. To ensure a consistent and responsive user experience across different devices, the application leverages the Bootstrap framework. Bootstrap provides a rich set of pre-designed components and a responsive grid system, significantly speeding up the development of a visually appealing interface.

### Slide 2: Hotwire for Dynamic Interactions
To deliver a modern, engaging user experience, the application incorporates the Hotwire framework, specifically Turbo and Stimulus. Turbo is instrumental in enabling faster navigation and dynamic content updates without full page reloads, mimicking the behavior of a Single Page Application. Stimulus, on the other hand, provides a structured way to connect JavaScript logic to HTML elements. This approach allows for organized, modular, and maintainable client-side interactivity, reducing the need for complex, custom JavaScript code.

### Slide 3: Asset Pipeline and Styling
For efficient asset management, the project utilizes `jsbundling-rails` with esbuild for JavaScript bundling and `cssbundling-rails` with Sass for CSS preprocessing. Sass allows for more organized and maintainable CSS by supporting features like variables, nesting, and mixins. The application also includes custom stylesheets, such as `login.css` and `about.css`, which provide specific styling and background images, complementing the overall Bootstrap theme and tailoring the look and feel for particular pages.