### Slide 3: Asset Pipeline and Styling
- **Sass:** Used for CSS preprocessing, enabling features like variables, nesting, and mixins for more maintainable stylesheets.
- **esbuild:** Integrated via `jsbundling-rails` for efficient JavaScript bundling.
- **Custom Styles:** Specific CSS files like `login.css` and `about.css` are included, complementing the Bootstrap framework with custom styles and background images.