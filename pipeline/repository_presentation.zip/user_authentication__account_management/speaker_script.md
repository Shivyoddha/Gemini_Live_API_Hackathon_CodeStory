## User Authentication & Account Management

### Slide 1: Devise for Authentication
User authentication and account management are handled robustly by the popular Devise gem. Devise provides a comprehensive suite of tools for secure user authentication. This includes essential functionalities such as user registration for new accounts, secure login processes, a password recovery mechanism for forgotten passwords, and email change confirmation to ensure the security of a user's account.

### Slide 2: Custom Sign-up Parameters
Beyond the standard authentication features, Devise has been customized to capture additional user information during the sign-up process. When a new user registers, the application now collects their `name`, `homelocation`, and `phoneno`. This extended information is managed securely through Rails' strong parameter filtering, as defined in the `configure_permitted_parameters` method within `ApplicationController`. This ensures that only the intended data is accepted and processed, maintaining data integrity and security.