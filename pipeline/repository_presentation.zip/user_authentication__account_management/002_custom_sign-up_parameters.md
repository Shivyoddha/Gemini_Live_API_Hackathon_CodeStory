### Slide 2: Custom Sign-up Parameters
- The Devise sign-up process is customized to collect additional user information:
    - `name`
    - `homelocation`
    - `phoneno`
- Strong parameter handling (`configure_permitted_parameters`) is used to ensure data security during these operations.