## Payment Processing
The application integrates **Razorpay** for secure online payment of application fees.

**Integration Details:**
*   **Razorpay Gem (`Gemfile`):** `gem 'razorpay'`.
*   **Configuration (`config/initializers/razorpay.rb`):**
    *   `Razorpay.setup('rzp_test_Bl2LHXvHavZ3p4', 'inBJBHNdmAQsjTx5eTddnKTv')`: Configures Razorpay with test API keys. These would be replaced with production keys in a live environment.
*   **Form Fee (`Form` model):** The `Form` model has a `fee` attribute (`integer`) to specify the application cost.
*   **Response Payment Status (`Response` model):** The `Response` model tracks payment with:
    *   `payment_status` (boolean): `true` if payment is successful.
    *   `amount` (integer): The amount paid for the application.
*   **Checkout Flow (`FormsController#checkout`):**
    *   An applicant navigates to the checkout page for a specific response (`forms/checkout.html.erb`).
    *   The Razorpay checkout script is embedded in this view, dynamically configured with `data-key` (the public key) and `data-amount` (the form's fee * 100 for paisa conversion).
    *   The `data-buttontext`, `data-name`, `data-description`, and `data-prefill` attributes customize the appearance and pre-fill details of the Razorpay payment modal.
*   **Payment Completion (`FormsController#payment`):**
    *   After successful payment via the Razorpay widget, a `PATCH` request is sent to the `payment_form_path`.
    *   The `payment` action in `FormsController` updates the `Response` record, setting `amount` to the `form.fee` and `payment_status` to `true`.
    *   Immediately after, `PaymentMailer.payment` is triggered to send a confirmation email to the applicant.
*   **Email Notification (`PaymentMailer`):**
    *   `app/mailers/payment_mailer.rb` defines the `payment` method, sending an email confirmation with the amount paid and job role.
    *   Default sender is `crfnitk@gmail.com` (configured in `ApplicationMailer`). SMTP settings for Gmail are configured in `config/environments/development.rb`.