## System Architecture

The IRIS Procurement Portal is built on the **Ruby on Rails 7.0** framework, adhering to the **Model-View-Controller (MVC)** architectural pattern. It uses **PostgreSQL** as its primary data store for robust and scalable persistence, with **bcrypt** for secure user authentication and password hashing.

The system's core components and their responsibilities are:

*   **Models (`app/models/`)**:
    *   `User`: Manages user authentication, roles (Buyer, Approver, Admin), and stores user details (`user_name`, `email`, `password_digest`, `is_admin`). It leverages `has_secure_password`.
    *   `DocA`: Represents Document A, managing its state through an `enum status`, approval dates (`u_date`, `p_date`, `q_date`, `r_date`, `s_date`), and remarks.
    *   `DocB`: Represents Document B, similarly managing its workflow and containing pre-filled data from DocA and its own approval history.
*   **Controllers (`app/controllers/`)**:
    *   `ApplicationController`: Establishes base behaviors, including `authenticate_user` (session-based) and `check_admin_access` for role-based authorization.
    *   `SessionsController`: Handles user login (`new`, `create`) and logout (`destroy`).
    *   `DashboardController`: Provides a centralized view for users, displaying pending approvals, documents created by the current user, and documents they have processed.
    *   `DocAsController`: Manages the lifecycle of Document A, including creation, viewing, and actions for approval/rejection, and triggers the auto-creation of Document B.
    *   `DocBsController`: Manages the lifecycle of Document B, including creation, viewing, and actions for approval/rejection.
    *   `AdminController`: Provides an interface for administrators to manage user details and roles.
*   **Views (`app/views/`)**: ERB templates that render the user interface, incorporating custom CSS for styling.
*   **Services (`app/services/`)**:
    *   `AutoCreateDocBService`: A dedicated service object responsible for the business logic of automatically generating Document B upon the final approval of Document A.
*   **Database**: PostgreSQL is used for data persistence (specified in `docker-compose.yml`, `INSTALL_SUMMARY.md`, `RENDER_DEPLOYMENT.md`, and `db/schema.rb`). Initial `config/database.yml` shows `sqlite3` but PostgreSQL is the deployed database.
*   **Mailer (`app/mailers/`)**: `ProcurementMailer` handles email notifications for various workflow events (submission, approval, rejection) using configured SMTP settings.

### System Components Diagram

```mermaid
graph TD
    A[User Interface] --> B(Rails Application)
    B --> C{Controllers}
    C --> D[Models]
    C --> E[Views]
    D --> F[Database: PostgreSQL]
    B --> G[Services: AutoCreateDocBService]
    B --> H[Mailer: ProcurementMailer]
    H --> I[External: Gmail SMTP]

    subgraph Rails Application
        C --- D
        C --- E
        C --- G
        H --- B
    end

    subgraph Data Layer
        D --- F
    end

    subgraph External Systems
        H --> I
    end

    style A fill:#e0f7fa,stroke:#00bcd4,stroke-width:2px
    style B fill:#f1f8e9,stroke:#8bc34a,stroke-width:2px
    style C fill:#fff3e0,stroke:#ff9800,stroke-width:1px
    style D fill:#e3f2fd,stroke:#2196f3,stroke-width:1px
    style E fill:#fffde7,stroke:#ffeb3b,stroke-width:1px
    style F fill:#e8f5e9,stroke:#4caf50,stroke-width:2px
    style G fill:#f3e5f5,stroke:#9c27b0,stroke-width:1px
    style H fill:#ffebee,stroke:#f44336,stroke-width:1px
    style I fill:#f5f5f5,stroke:#9e9e9e,stroke-width:1px
```