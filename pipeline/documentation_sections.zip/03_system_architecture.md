## System Architecture

The IRIS Procurement Portal is built upon the classic Ruby on Rails MVC (Model-View-Controller) architecture, utilizing PostgreSQL for data persistence and Docker for environment consistency.

**Core Components:**
*   **Rails Application (Web)**: The central component, handling business logic, data presentation, and user interaction. It's built with Ruby on Rails 7.0 and served by Puma.
*   **PostgreSQL Database (DB)**: The primary data store for all application information, including users, DocAs, and DocBs.
*   **User Authentication**: Implemented via `bcrypt` for secure password hashing and Rails' session management for user login/logout.
*   **Procurement Workflow Logic**: Encapsulated within `DocA` and `DocB` models and their respective controllers (`DocAsController`, `DocBsController`), which manage state transitions and record approval details.
*   **Service Objects**: `AutoCreateDocBService` handles the automatic generation of Document B upon Document A's full approval, promoting single responsibility.
*   **Email Notification System**: `ProcurementMailer` is responsible for sending transactional emails triggered by workflow events, configured to use Gmail SMTP.
*   **Containerization**: Docker and Docker Compose are used to package the application and its dependencies, providing isolated and reproducible development and deployment environments.

**System Structure Overview:**

```mermaid
graph TD
    A[User Interface (Browser)] -- HTTP Requests --> B[Rails Web Application (Puma)]
    B --> C[ApplicationController]
    B --> D[SessionsController]
    B --> E[DashboardController]
    B --> F[DocAsController]
    B --> G[DocBsController]
    B --> H[AdminController]
    C --> I[Models (User, DocA, DocB)]
    D --> I
    E --> I
    F --> I
    G --> I
    H --> I
    F --> J[AutoCreateDocBService]
    G --> K[ProcurementMailer]
    F --> K
    I -- Data Persistence --> L[PostgreSQL Database]
    K -- SMTP --> M[Gmail SMTP Server]
```

**Key Technologies:**

| Category          | Technology/Tool      | Version/Details                                                                               | Purpose                                                             |
| :---------------- | :------------------- | :-------------------------------------------------------------------------------------------- | :------------------------------------------------------------------ |
| **Framework**     | Ruby on Rails        | 7.0                                                                                           | Web application framework, MVC pattern                              |
| **Language**      | Ruby                 | 3.2.0                                                                                         | Primary programming language                                        |
| **Database**      | PostgreSQL           | Used in Docker, Render, and recommended local setup (`sqlite3` is default for dev/test in Gemfile, but PostgreSQL setup is provided) | Relational database for data storage                                |
| **Web Server**    | Puma                 | ~> 6.0                                                                                        | Production-ready web server                                         |
| **Authentication**| bcrypt               | ~> 3.1.7                                                                                      | Secure password hashing                                             |
| **Frontend**      | ERB, Custom CSS      | (No specific frontend framework like React/Vue)                                               | Templating engine for views, custom stylesheets for UI              |
| **Containerization**| Docker, Docker Compose | (latest compatible)                                                                           | Consistent development/deployment environments                      |
| **Email**         | ActionMailer         | (Rails built-in)                                                                              | Email sending framework                                             |
| **Email Service** | Gmail SMTP           | smtp.gmail.com:587                                                                            | External service for sending emails                                 |
| **Deployment**    | Render               | `render.yaml`, `Procfile` configured                                                        | Cloud platform for application deployment                           |