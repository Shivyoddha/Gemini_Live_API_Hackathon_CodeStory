## Procurement Workflow Management

The system implements a structured, sequential approval workflow for two distinct document types: Document A (initial procurement request) and Document B (follow-up document). The workflow is fixed across a chain of five roles: one Buyer (U) and four Approvers (P, Q, R, S).

### Workflow Stages and Responsibilities

1.  **Initiation (by Buyer U)**:
    *   A Buyer (U) creates a new Document A (or Document B if initiated independently, though typically Document B follows A).
    *   For Document A, the Buyer fills in basic equipment details (ID, name, cost, head) and initial remarks (`u_remarks`). Equipment IDs are auto-generated in the format `CSE_X`.
    *   Upon submission, the document's status is set to `pending_p_approval`, `u_date` is captured, and it is automatically forwarded to Approver P. An email notification is sent to P.

2.  **Sequential Approval (by P, Q, R, S)**:
    *   Each approver (P, Q, R, S) logs in and sees documents pending their approval on the dashboard.
    *   They review the document details and previous remarks.
    *   The approver can either:
        *   **Approve**: Add their `_remarks`, their `_date` is auto-captured, and the document's `status` is updated to the next stage (e.g., `pending_p_approval` → `pending_q_approval`). Email notifications are sent to the Buyer (U) about the status change and to the next approver.
        *   **Reject**: Add their `_remarks`, their `_date` is auto-captured, and the document's `status` is set to `rejected`. An email notification is sent to the Buyer (U) with the rejection reason.

3.  **Document A Completion & Auto-Generation of Document B**:
    *   Once Document A is approved by Approver S (setting status to `approved`), an email notification is sent to Buyer (U) confirming final approval.
    *   The `AutoCreateDocBService` is triggered, which automatically generates a new Document B.
    *   Document B is pre-filled with the `eq_id`, `name`, `cost`, and `head` from the approved Document A.
    *   The newly created Document B is initiated by Buyer (U) with status `draft` and immediately forwarded to Approver P for its own approval cycle.

4.  **Document B Workflow**:
    *   Document B follows the *exact same sequential approval flow* (U → P → Q → R → S) as Document A, with similar email notifications at each stage.
    *   The status enum (`draft`, `pending_p_approval`, ..., `approved`, `rejected`) is identical for both document types.

### Status Transitions

The `status` enum (`DocA` and `DocB` models) defines the states:
*   `draft`: Initial state for newly created documents.
*   `pending_p_approval`: Waiting for Approver P.
*   `pending_q_approval`: Waiting for Approver Q.
*   `pending_r_approval`: Waiting for Approver R.
*   `pending_s_approval`: Waiting for Approver S.
*   `approved`: Fully approved by all approvers.
*   `rejected`: Rejected at any stage by an approver.

### Document A Approval Sequence Diagram

```mermaid
sequenceDiagram
    participant U as Buyer (U)
    participant P as Approver P
    participant Q as Approver Q
    participant R as Approver R
    participant S as Approver S
    participant App as Rails Application
    participant Mailer as Email System
    participant DocBService as AutoCreateDocBService

    U->>App: Creates new Doc A (fills name, cost, head, u_remarks)
    App->>App: Auto-generates eq_id, sets u_date
    App->>App: Saves Doc A with status: draft
    App->>App: Updates Doc A status to: pending_p_approval
    App->>Mailer: Send 'Doc A Submitted' to P
    App-->>U: Redirect to Doc A details, "Forwarded to P" notice

    P->>App: Logs in, views pending Doc A
    P->>App: Submits 'Approve' with p_remarks
    App->>App: Updates Doc A: p_date, p_remarks, status: pending_q_approval
    App->>Mailer: Send 'Doc A Approved (by P, to Q)' to U
    App->>Mailer: Send 'Doc A Requires Approval' to Q
    App-->>P: Redirect to dashboard, "Document approved" notice

    Q->>App: Logs in, views pending Doc A
    Q->>App: Submits 'Approve' with q_remarks
    App->>App: Updates Doc A: q_date, q_remarks, status: pending_r_approval
    App->>Mailer: Send 'Doc A Approved (by Q, to R)' to U
    App->>Mailer: Send 'Doc A Requires Approval' to R
    App-->>Q: Redirect to dashboard, "Document approved" notice

    R->>App: Logs in, views pending Doc A
    R->>App: Submits 'Approve' with r_remarks
    App->>App: Updates Doc A: r_date, r_remarks, status: pending_s_approval
    App->>Mailer: Send 'Doc A Approved (by R, to S)' to U
    App->>Mailer: Send 'Doc A Requires Approval' to S
    App-->>R: Redirect to dashboard, "Document approved" notice

    S->>App: Logs in, views pending Doc A
    S->>App: Submits 'Approve' with s_remarks
    App->>App: Updates Doc A: s_date, s_remarks, status: approved
    App->>Mailer: Send 'Doc A Fully Approved' to U
    App->>DocBService: call(Doc A, current_user)
    DocBService->>App: Creates Doc B (pre-filled from Doc A), status: draft
    App->>App: Updates Doc B status to: pending_p_approval
    App->>Mailer: Send 'Doc B Submitted' to P
    App-->>S: Redirect to dashboard/new Doc B path, "Doc A approved, complete Doc B" notice
```