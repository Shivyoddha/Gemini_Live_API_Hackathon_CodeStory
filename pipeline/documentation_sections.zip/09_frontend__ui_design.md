## Frontend & UI Design

The IRIS Procurement Portal features a modern, responsive user interface designed for clarity and ease of use, built with ERB templates and custom CSS.

**Key UI Elements and Design Principles:**

*   **Layout (`app/views/layouts/application.html.erb`)**:
    *   **Header**: Consistent header with "IRIS Procurement Portal" title, current user information (`display_name_or_username`), and logout button. An "Admin" link is visible if the user has admin privileges.
    *   **Main Content Area**: Dynamically renders content from individual views.
    *   **Flash Messages**: `notice` and `alert` messages are displayed prominently at the top of the content area or as fixed pop-ups on the login page.
    *   **Login Page Specific Styling**: A distinct full-screen background image (`beach.jpeg`) and a centralized login card.
*   **Styling (`app/assets/stylesheets/application.css`, `app/views/layouts/application.html.erb` inline CSS)**:
    *   **Modern Aesthetic**: Utilizes a clean, flat design with soft shadows and gradients for a professional look.
    *   **Responsive Design**: Styles are crafted to ensure the application is usable across various screen sizes (implied by general CSS and use of `max-width`, `padding`, `gap`).
    *   **Color Palette**: Employs blue (`#2563eb`), green (`#059669`), red (`#dc2626`), and grey tones for primary actions, success, danger, and secondary elements respectively.
*   **Dashboard (`app/views/dashboard/index.html.erb`)**:
    *   **Welcome Message**: Greets the logged-in user by their display name.
    *   **Pending Approvals**: For approvers, a dedicated section lists documents awaiting their review, categorized by Document A and Document B.
    *   **My Documents / Processed Documents**:
        *   For buyers, tabs (Document A, Document B) display their initiated documents with status badges and actions (View, Create Document B).
        *   For approvers, lists documents they have processed, showing creation details and current status.
    *   **Action Buttons**: Prominent buttons for "New Document A", "New Document B", "Review", "View".
*   **Forms (`app/views/doc_as/new.html.erb`, `app/views/doc_bs/new.html.erb`, `app/views/admin/edit_user.html.erb`)**:
    *   **Standardized Form Groups**: Labels, input fields (`text`, `number`, `password`, `textarea`, `select`), and validation error displays are consistently styled.
    *   **Auto-generated Fields**: Equipment ID (`eq_id`) is clearly displayed as auto-generated.
    *   **Cost Input**: Includes a "Rs." prefix for clear currency indication.
    *   **Read-only Fields**: For Document B, fields pre-filled from Document A are marked as read-only.
*   **Document Details Views (`app/views/doc_as/show.html.erb`, `app/views/doc_bs/show.html.erb`)**:
    *   **Card-based Layout**: Organizes information into digestible "Basic Information" and "Approval History" cards.
    *   **Tables**: Used for structured display of document attributes and approval history (User, Date, Remarks).
    *   **Status Badges**: Visual badges (`badge-success`, `badge-warning`, `badge-danger`, `badge-info`) with color coding (`badge_color_for_status` helper in `app/helpers/`) provide immediate status cues.
*   **Approval/Rejection Interface**:
    *   **Conditional Display**: Action forms (Approve/Reject) are only shown to the current designated approver.
    *   **Remarks Input**: A dedicated text area for approvers to add their remarks.
    *   **Rejection Form**: A hidden rejection form is revealed on clicking "Reject" to prompt for a rejection reason.
*   **Admin Panel (`app/views/admin/index.html.erb`, `app/views/admin/edit_user.html.erb`)**:
    *   **User List**: Displays a table of all users with their username, display name, email, role, and admin status.
    *   **Edit User**: Form for modifying user details, including an option to leave password blank for no change.
*   **Login Page (`app/views/sessions/new.html.erb`)**:
    *   Custom-styled login card.
    *   Lists prototype login credentials (Username, Display Name, Email, Password, Role) in a table for easy testing, with a quick login tip.
*   **Email Templates (`app/views/procurement_mailer/*.html.erb`)**:
    *   Follow a consistent layout (`app/views/layouts/mailer.html.erb`) with a header, content area, info boxes for document details, and a footer.
    *   Utilize simple, clean HTML and CSS for broad email client compatibility.