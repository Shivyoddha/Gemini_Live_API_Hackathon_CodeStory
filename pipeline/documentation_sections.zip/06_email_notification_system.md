## Email Notification System

The IRIS Procurement Portal includes a robust email notification system designed to keep all stakeholders informed about procurement document status changes. It utilizes Gmail's SMTP service for sending emails and is configured to be non-blocking, ensuring application stability even if email delivery encounters issues.

### Key Features

*   **Automated Notifications**: Sends emails for critical workflow events:
    *   **Document Submission**: To the next approver (P, Q, R, S) when a document is forwarded to them.
    *   **Document Approval**: To the Buyer (U) and the next approver in the chain when an approver approves a document.
    *   **Document Final Approval**: To the Buyer (U) when a document (Doc A or Doc B) is fully approved by S.
    *   **Document Rejection**: To the Buyer (U) when an approver rejects a document, including the rejection reason.
*   **Gmail SMTP Integration**: Configured to use `smtp.gmail.com` with port `587` and `plain` authentication, requiring a Gmail app password.
*   **Non-Blocking Delivery**: Email sending actions in controllers (`DocAsController`, `DocBsController`) are wrapped in `begin...rescue` blocks. Failed email deliveries are logged (`Rails.logger.error`) but do not halt the application workflow, preserving user experience.
*   **Environment Variable Configuration**: Sensitive credentials (`GMAIL_USERNAME`, `GMAIL_PASSWORD`) are managed via environment variables, enhancing security for both development and production environments.
*   **Customizable Templates**: Email content is generated using ERB templates (`app/views/procurement_mailer/`), allowing for a branded and informative user experience. HTML and plain text versions are supported.

### Configuration Details

| Setting                   | Value/Source                                     | Files                                                                 |
| :------------------------ | :----------------------------------------------- | :-------------------------------------------------------------------- |
| **Sender Email**          | `ENV['GMAIL_USERNAME']` (default: `anish.kumbhar02@gmail.com`) | `app/mailers/application_mailer.rb`, `config/initializers/gmail_config.rb`, `config/environments/*.rb` |
| **SMTP Server Address**   | `smtp.gmail.com`                                 | `config/environments/*.rb`                                            |
| **SMTP Port**             | `587`                                            | `config/environments/*.rb`                                            |
| **SMTP Authentication**   | `plain`                                          | `config/environments/*.rb`                                            |
| **App Password**          | `ENV['GMAIL_PASSWORD']` (default: `tdumhmfldwrkgtqu`) | `config/initializers/gmail_config.rb`, `config/environments/*.rb`       |
| **Default URL Options**   | `host: ENV['APP_HOST']` (default: `localhost:3000` or IP) | `config/environments/*.rb`                                            |

The `config/initializers/gmail_config.rb` file serves as a central point for default Gmail credentials if environment variables are not explicitly set, primarily for local development convenience.

### Email Recipient Logic (from `app/mailers/procurement_mailer.rb`)

Emails are sent to recipients based on their `User` record's `email` attribute. If a user record's email is not present, a default email is used:

*   **Buyer (U)**: `anish.kumbhar04@gmail.com`
*   **Approvers (P, Q, R, S)**: `brc@nitk.edu.in`

### Debugging and Testing

The repository provides dedicated scripts to assist with email functionality:

*   **`debug_email.rb`**: A script to be loaded in the Rails console (`rails console`) that checks environment variables, Rails mailer configuration, attempts an SMTP connection, and tries to send a test email. It provides detailed output for troubleshooting common issues like incorrect app passwords or Gmail settings.
*   **`test_email.rb`**: Another console script that sends specific test emails to User U and Approver P, useful for verifying mailer functionality after changes.

These tools are crucial for ensuring the email system is correctly configured and operational in different environments.