## Email Notification System

The application incorporates a comprehensive email notification system to keep users informed about document status changes.

**Overview:**

*   **Purpose**: Notify approvers of new documents requiring their action and notify buyers of document approvals or rejections.
*   **Sender**: `anish.kumbhar02@gmail.com` (configurable via `GMAIL_USERNAME` environment variable).
*   **SMTP**: Configured for Gmail's SMTP server (`smtp.gmail.com:587`).
*   **Authentication**: Uses Gmail App Passwords, set via `GMAIL_PASSWORD` environment variable or `config/initializers/gmail_config.rb`.
*   **Non-blocking Send**: Emails are sent using `.deliver_now` but error handling ensures that email failures do not crash the application, logging errors instead.

**Key Email Events and Recipients:**

1.  **New Document Submission**:
    *   **Trigger**: User U creates `DocA` or `DocB` and forwards it to P.
    *   **Recipient**: Current approver (e.g., P, Q, R, S).
    *   **Content**: Document details (ID, Name, Cost, Head), creator, submission date, and a link to the portal.
2.  **Document Approved**:
    *   **Trigger**: Any approver (P, Q, R, S) approves a document.
    *   **Recipient**: User U (buyer) and the *next* approver in the chain (if applicable).
    *   **Content**: Document details, approval status, and who approved it.
3.  **Document Fully Approved**:
    *   **Trigger**: Document A or B receives final approval from S.
    *   **Recipient**: User U (buyer).
    *   **Content**: Final approval notification for the document.
4.  **Document Rejected**:
    *   **Trigger**: Any approver (P, Q, R, S) rejects a document.
    *   **Recipient**: User U (buyer).
    *   **Content**: Document details, rejection status, and the approver's remarks.

**Email Configuration:**

*   **`config/environments/development.rb` / `production.rb`**: Contains the `config.action_mailer.smtp_settings` hash, specifying the SMTP server, port, domain, authentication method, and credentials (retrieved from environment variables).
*   **`config/initializers/gmail_config.rb`**: Sets default `GMAIL_USERNAME` and `GMAIL_PASSWORD` environment variables if not already present, ensuring mailer functionality during local development.
*   **`app/mailers/application_mailer.rb`**: Sets the default `from` address to `ENV['GMAIL_USERNAME']` and uses the `mailer` layout.
*   **`app/mailers/procurement_mailer.rb`**:
    *   Defines methods `document_submitted_to_approver`, `document_approved_status`, `document_rejected_status`.
    *   Dynamically determines recipient emails based on `User` records or predefined defaults if user email is not present.
    *   Includes `@document`, `@approver_name`, `@creator`, `@status_message`, `@rejection_message`, `@display_name` instance variables for use in templates.

**Email Templates:**

*   **Location**: `app/views/procurement_mailer/`
    *   HTML templates (`.html.erb`) for rich-text emails.
    *   Plain text templates (`.text.erb`) for basic email clients.
*   **Layout**: `app/views/layouts/mailer.html.erb` provides a consistent branding (IRIS header, footer, info boxes) for all notifications.
*   **Content**: All emails include:
    *   Header with "IRIS Procurement Portal" branding.
    *   Document ID, Name, Cost, Head.
    *   Status information or rejection reason.
    *   Relevant links to the portal (e.g., "View Dashboard", "Review Document").
    *   Footer with copyright and automated message notice.

**Example Email Data Flow (Document A Submission):**

```mermaid
sequenceDiagram
    actor U as User U (Buyer)
    participant DA_Ctrl as DocAsController
    participant PM as ProcurementMailer
    participant UserDB as User Database
    participant SMTP as Gmail SMTP
    actor P as Approver P

    U->>DA_Ctrl: Creates new DocA
    DA_Ctrl->>UserDB: Retrieve User P's email (if available)
    DA_Ctrl->>PM: ProcurementMailer.document_submitted_to_approver(doc_a, 'P').deliver_now
    PM->>SMTP: Sends email with HTML/Text content
    SMTP-->>P: Delivers email to P
```