## Email Notification Service
The application utilizes **Action Mailer** to send automated email notifications for crucial events within the recruitment process.

**Configuration (`config/environments/development.rb`):**
*   `config.action_mailer.raise_delivery_errors = true`: Ensures that errors during email delivery are reported.
*   `config.action_mailer.delivery_method = :smtp`: Specifies SMTP as the email delivery method.
*   `config.action_mailer.perform_deliveries = true`: Enables email sending.
*   `config.action_mailer.default_options = {from: 'crfnitk@gmail.com'}`: Sets the default sender address.
*   **SMTP Settings (Gmail):**
    *   `address: 'smtp.gmail.com'`
    *   `port: '587'`
    *   `user_name: 'crfnitk@gmail.com'`
    *   `password: 'hcgzyqpdxgcnxwha'` (App-specific password, should be stored securely in credentials for production)
    *   `authentication: :plain`
    *   `enable_starttls_auto: true`
*   `config.action_mailer.default_url_options`: Appears to be an incomplete line in the provided `development.rb`. This would typically be set to the application's host for generating full URLs in emails.

**Mailers (`app/mailers`):**
1.  **`ApplicationMailer` (`app/mailers/application_mailer.rb`):**
    *   Base class for all application mailers.
    *   `default from: "crfnitk@gmail.com"`: Sets the default sender for all emails originating from this application.
    *   `layout "mailer"`: Specifies the `app/views/layouts/mailer.html.erb` as the default layout for email content.
2.  **`PaymentMailer` (`app/mailers/payment_mailer.rb`):**
    *   **Purpose:** Notifies applicants upon successful payment of application fees.
    *   **Trigger:** Called from `FormsController#payment` after updating `Response` payment status.
    *   **`payment` method:** Retrieves `User`, `Response`, and `Form` objects using `params` to personalize the email.
    *   **View (`app/views/payment_mailer/payment.html.erb`):** Informs the user about the amount paid and the role applied for.
3.  **`CreditValidateMailer` (`app/mailers/credit_validate_mailer.rb`):**
    *   **Purpose:** Notifies applicants about the outcome of their credit validation.
    *   **Trigger:** Implied to be triggered after a validator updates the `verified_credit` or `eligibility` for a `Response` (though not explicitly shown in `CreditAnswersController#update` or `ResponsesController#update_eligibility` in the provided code, it's a logical next step based on the description and mailer existence).
    *   **`success` method:** Sends a positive notification if credit validation is successful.
    *   **`failure` method:** Sends a notification if the credit validation is unsuccessful.
    *   **View (`app/views/credit_validate_mailer/success.html.erb`, `app/views/credit_validate_mailer/failure.html.erb`):** Contains simple messages for success or failure.
4.  **`FormResponseMailer` (`app/mailers/form_response_mailer.rb`):**
    *   Contains an empty `form_filled` method. This suggests it might be a placeholder for future functionality to notify users or administrators when a general application form is filled, but it's not currently implemented or called in the provided code.

**Email Layouts:**
*   `app/views/layouts/mailer.html.erb`: Standard HTML layout for emails.
*   `app/views/layouts/mailer.text.erb`: Plain text version for email clients that don't render HTML.

The email service ensures that users are kept informed about critical stages of their application, such as payment confirmation and credit evaluation outcomes.