## User Roles and Authentication

The IRIS Procurement Portal implements a role-based access control system to manage user permissions and workflow responsibilities.

### User Roles

The system defines the following distinct roles:

*   **Buyer (U)**:
    *   Can initiate new Document A and Document B requests.
    *   Tracks the status of their submitted documents.
    *   Receives notifications about document approvals or rejections.
    *   Has `user_name` 'U'.
*   **Approvers (P, Q, R, S)**:
    *   Review documents pending their approval.
    *   Can approve or reject documents, adding remarks and capturing approval dates.
    *   Receive notifications when a new document requires their action.
    *   Each has a unique `user_name` ('P', 'Q', 'R', 'S') representing their position in the sequential approval chain.
*   **Administrator (admin)**:
    *   Manages user accounts, including editing display names, emails, and passwords for existing users.
    *   Has `user_name` 'admin' and `is_admin` set to true.

### Authentication

User authentication is implemented using:

*   **`bcrypt` Gem**: Passwords are securely hashed and stored as `password_digest` in the `users` table, preventing plaintext password storage. The `User` model utilizes `has_secure_password` for this functionality.
*   **Session Management**: User sessions are managed by storing `session[:user_id]` upon successful login, which allows the application to identify `current_user` across requests.
*   **Login/Logout**: The `SessionsController` handles user login (validating `user_name` and `password` against hashed credentials) and logout (clearing the session).
*   **Role-Based Access Control**:
    *   `ApplicationController` enforces `authenticate_user` for all actions by default, redirecting unauthenticated users to the login page.
    *   `check_admin_access` `before_action` (in `ApplicationController`) restricts access to `/admin` routes to users with `admin?` privileges, redirecting others to the dashboard with an alert.
    *   The `User` model defines `buyer?`, `approver?`, and `admin?` helper methods to simplify role checks within the application logic and views.

### User Management Interface (Admin)

An `AdminController` provides the following functionality:

*   **`admin#index`**: Displays a table of all registered users, their `user_name`, `display_name`, `email`, derived `Role` (Buyer, Approver, Admin), and `is_admin` status.
*   **`admin#edit_user`**: Allows an administrator to edit the `display_name`, `email`, and optionally reset the `password` for any user. Password fields can be left blank if no change is desired.
*   **`admin#update_user`**: Processes the user updates, including password hashing if a new password is provided.

### Default Credentials (from `db/seeds.rb` and `app/views/sessions/new.html.erb`)

| Username | Display Name  | Email                  | Password  | Role        | Admin |
| :------- | :------------ | :--------------------- | :-------- | :---------- | :---- |
| `admin`  | Administrator | admin@gmail.com        | `123456`  | Admin       | Yes   |
| `U`      | Buyer         | anish.kumbhar04@gmail.com | `U123`    | Buyer       | No    |
| `P`      | Approver P    | brc@nitk.edu.in        | `P123`    | Approver    | No    |
| `Q`      | Approver Q    | brc@nitk.edu.in        | `Q123`    | Approver    | No    |
| `R`      | Approver R    | brc@nitk.edu.in        | `R123`    | Approver    | No    |
| `S`      | Approver S    | brc@nitk.edu.in        | `S123`    | Approver    | No    |