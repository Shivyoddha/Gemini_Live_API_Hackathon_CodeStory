## Credit Calculation & Validation Module
This module handles the evaluation of applicants based on a credit scoring system and provides a workflow for validators to review and verify these credits.

**Core Models and Relationships:**
*   **`CreditSection` (`app/models/credit_section.rb`, `credit_sections` table):** Organizes credit-based questions into logical sections.
    *   `title`: Name of the section (e.g., "Experience", "Publications").
    *   `has_many :credit_questions, dependent: :destroy`: Sections contain credit questions.
    *   `has_many :credit_answers, dependent: :destroy`: Each section can have multiple credit answers.

*   **`CreditQuestion` (`app/models/credit_question.rb`, `credit_questions` table):** Defines individual credit-earning activities.
    *   `title`: The credit question (e.g., "Years of Experience", "Number of Publications").
    *   `max_credit`: Maximum credit obtainable for this question.
    *   `obt_credit`: Credit value obtained per unit of answer (e.g., credit per year, per publication).
    *   `isheader`: Boolean, indicating if this question acts as a header for sub-questions.
    *   `header_id`: Self-referential foreign key to link sub-questions to a header question.
    *   `belongs_to :credit_section, optional: true`.
    *   `belongs_to :header, class_name: "CreditQuestion", foreign_key: "header_id", optional: true`.
    *   `has_many :sub_questions, class_name: "CreditQuestion", foreign_key: "header_id"`.

*   **`CreditAnswer` (`app/models/credit_answer.rb`, `credit_answers` table):** An applicant's response to a `CreditQuestion`.
    *   `answer`: The numerical answer provided by the applicant.
    *   `credit`: Calculated credit for this specific answer based on `obt_credit` and `max_credit`.
    *   `verified_credit`: The credit verified by a validator.
    *   `verified_count`: The count verified by a validator.
    *   `is_upload`: Boolean, indicating if a file upload is associated with this answer.
    *   `file_upload` (Active Storage): Attachment for supporting documents.
    *   `belongs_to :credit_question, optional: true`, `belongs_to :response, optional: true`, `belongs_to :credit_section, optional: true`.

*   **`Response` (`app/models/response.rb`):** Contains `credit_score`, `validation`, `remark`, and `eligibility` to track the overall credit status of an application.

**Credit Workflow:**
1.  **Credit Question Creation:** Administrators define `CreditSection`s and `CreditQuestion`s, setting `max_credit`, `obt_credit`, and structuring them with headers and sub-questions if needed. `CreditQuestion`s can also be imported via CSV using `CsvImportService`.
2.  **Applicant Submission (`CreditAnswersController#new`, `#create`):** Applicants provide numerical answers to credit questions. The system automatically calculates `credit` for each `CreditAnswer` (capped at `max_credit`) and sums them up to determine the `Response#credit_score`. If the total `credit_score` is less than the `Form#credit_req`, the submission is rejected, and the applicant is prompted to resubmit.
3.  **File Uploads for Credit Claims:** `CreditAnswer` supports `file_upload` for applicants to submit supporting documents for their credit claims (e.g., certificates, publications).
4.  **Validator Interface (`HomeController#validate`, `ResponsesController#validate`, `CreditAnswersController#update`):** Designated users with a `validator` role can access a dashboard (`home/validate.html.erb`) to view all responses relevant to their department (`response.form.dept == @user.validator`).
    *   Validators can then drill down into a specific response (`responses/validate.html.erb`) to see individual `CreditAnswer`s.
    *   For each `CreditAnswer`, validators can review the applicant's `answer` and `credit`, view associated `file_upload`s, and manually input `verified_count` and `verified_credit`.
    *   Updating a `CreditAnswer` automatically recalculates the overall `Response#credit_score` using the `verified_credit` values and sets `Response#validation` to true.
    *   Validators can add `remark`s and manually update `Response#eligibility`.
5.  **Email Notifications:** `CreditValidateMailer` sends automated emails (success/failure) to applicants based on the validation outcome.