## Frontend Design and User Interface

The IRIS Procurement Portal features a clean, modern, and responsive user interface designed for intuitive navigation and efficient workflow management. The frontend is built using **ERB templates** (`app/views/`) for dynamic content generation, with extensive **custom CSS** (`app/views/layouts/application.html.erb` and `app/views/sessions/new.html.erb` contain significant inline CSS, indicating a custom design approach) to deliver a distinct look and feel.

### Core UI Principles

*   **Modern Aesthetic**: Utilizes a gradient-based background (specifically for the login page) and a balanced color palette for a professional appearance.
*   **Responsiveness**: Designed to be accessible and usable across various screen sizes, leveraging flexible layouts and CSS properties.
*   **Clarity and Simplicity**: Focuses on presenting information clearly and providing straightforward pathways for user actions.

### Key UI Components and Features

1.  **Global Layout (`app/views/layouts/application.html.erb`)**:
    *   **Header**: A fixed header with the "IRIS Procurement Portal" title and user information (display name, Admin link if applicable) and a logout button.
    *   **Content Area**: Main area for rendering specific page content, including `notice` and `alert` flash messages.
    *   **Custom Styling**: Defines global CSS for basic elements like `body`, `container`, `header`, `buttons` (`btn`, `btn-primary`, `btn-secondary`, `btn-success`, `btn-danger`), `alerts`, `forms`, `cards`, and `tables`.
    *   **Login Page Specific Styles**: A unique background image and centered layout for the `/login` route.

2.  **Login Page (`app/views/sessions/new.html.erb`)**:
    *   Presents a clean login form for username and password.
    *   Includes a prominent table of **prototype login credentials** for all defined users (Admin, Buyer U, Approvers P, Q, R, S), making it easy for new users to get started. Each entry includes username, display name, email, password pattern, and role with color-coded badges.
    *   Features dynamic styling for alerts and form elements.

3.  **Dashboard (`app/views/dashboard/index.html.erb`)**:
    *   **Personalized Welcome**: Greets the `current_user` by their display name.
    *   **Role-Specific Views**:
        *   **Approvers**: See a "Pending My Approval" section, listing Doc A and Doc B documents requiring their action, with links to review details. Also displays "Documents I've Processed".
        *   **Buyers**: See "My Documents" with options to create new Document A or Document B. Uses a **tabbed interface** (client-side JavaScript) to switch between lists of "Document A" and "Document B" applications created by the user, showing their current status.
    *   **Status Badges**: Documents are displayed with **color-coded status badges** (e.g., green for 'approved', red for 'rejected', yellow for 'pending') for quick visual identification of their state, leveraging `badge_color_for_status` helper methods.
    *   **Action Buttons**: Quick links to "Review" documents or "Create Document B" (if Document A is approved and Doc B doesn't exist yet).

4.  **Document Forms (New/Show for Doc A & Doc B)**:
    *   **`new.html.erb`**: Provides structured forms for creating documents, with clear labels and input fields.
        *   **Auto-generated Equipment ID**: Displays a read-only field for `eq_id`, clearly indicating it's auto-generated, in a distinct blue info box.
        *   **Pre-filled Fields**: For `new_doc_b` when triggered from an approved `DocA`, fields like `eq_id`, `name`, `cost`, `head` are automatically populated and set as read-only.
        *   **Required Fields**: Marked as required (`required: true`).
    *   **`show.html.erb`**: Displays detailed information in a card-based layout with tables for:
        *   **Basic Information**: `eq_id`, `name`, `cost`, `head`, `status` (with badge).
        *   **Approval History**: A table detailing each user's (`U`, `P`, `Q`, `R`, `S`) approval date and remarks, providing a complete audit trail.
    *   **Inline Approval/Rejection Forms**: For documents pending the `current_user`'s approval, an "Action Required" section appears with a text area for remarks and "Approve" and "Reject" buttons. The "Reject" button reveals a separate form for rejection reasons.

5.  **Admin Interface (`app/views/admin/`)**:
    *   Provides tables for user management.
    *   Allows administrators to edit user details (`display_name`, `email`, `password`) through dedicated forms.

### Helper Modules

Frontend helpers like `DashboardHelper`, `DocAsHelper`, and `DocBsHelper` contain `badge_color_for_status(status)` methods, which dynamically assign CSS classes (e.g., `badge-success`, `badge-warning`, `badge-danger`) based on the document's status, reinforcing the color-coded feedback system.