## File Management & PDF Generation
The application provides robust file management capabilities through Active Storage and generates comprehensive PDF reports using WickedPDF.

**File Management (Active Storage):**
Active Storage is configured for local storage (`config/storage.yml` sets `service: Disk` for `local` and `test` environments).
*   **User Profile (`app/models/user.rb`):**
    *   `has_one_attached :photo`: For applicant's passport-size photograph.
    *   `has_one_attached :sign`: For applicant's signature.
    *   These are managed via Devise registration/edit forms (`devise/registrations/new.html.erb`, `devise/registrations/edit.html.erb`).
    *   Images are Base64 encoded for embedding directly into PDF reports (`ResponsesController#print`).
*   **Form Responses (`app/models/answer.rb`):**
    *   `has_one_attached :file`: For general file upload questions within dynamic forms (QuestionType 9).
*   **Credit Answers (`app/models/credit_answer.rb`):**
    *   `has_one_attached :file_upload`: For supporting documents related to credit claims. The `is_upload` boolean column in `CreditAnswer` likely signifies if a file is expected/attached.
*   **Dedicated File Uploads (`app/models/file_upload.rb`, `file_uploads` table):**
    *   `has_many_attached :file`: Though the model name is `FileUpload`, the schema `t.binary :file` and controller `file_upload_params.permit(:file)` suggest a single file per record is stored, or potentially the `has_many_attached` might be a conceptual choice not fully reflected in the migration/schema. It's likely intended for multiple file attachments, but `file_uploads` table only has one `file` column as `binary`. The controller `file_uploads_controller.rb` creates multiple `FileUpload` records for multiple files.
    *   `belongs_to :upload_question, optional: true`.
    *   `belongs_to :response, optional: true`.
    *   `UploadSection` and `UploadQuestion` models exist to categorize these uploads.

**PDF Generation (WickedPDF):**
*   The `wicked_pdf` gem is used in conjunction with `wkhtmltopdf-binary` to convert HTML content into PDF documents.
*   **Configuration (`config/initializers/wicked_pdf.rb`):**
    *   `exe_path`: Configured to point to the `wkhtmltopdf.exe` executable, indicating a Windows development environment or specific deployment setup.
    *   `enable_local_file_access: true`: Essential for including local assets like images and stylesheets within the generated PDF.
*   **Application PDF (`ResponsesController#print`, `responses/displaypdf.html.erb`):**
    *   Generates a detailed PDF report of an applicant's entire application.
    *   The `displaypdf.html.erb` template is specifically designed for PDF output, using `wicked_pdf_stylesheet_link_tag` for `pdf_styles.css` and `wicked_pdf_asset_base64` for embedding images (like the NITK emblem, user photo, and signature).
    *   The PDF includes job description, applicant profile (photo, signature), and answers to all form questions, structured by question type (text, tabular, etc.).
    *   The `margin` option is set to `0` for full control over the layout.
*   **Viewing Uploaded PDFs:** The `ResponsesController#view_pdf` and `FormsController#view_pdf` actions are used to stream attached PDF files (from `CreditAnswer` or `Answer` models) directly to the browser for inline viewing.