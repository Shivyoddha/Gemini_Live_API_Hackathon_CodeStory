## User Management & Access Control
User authentication is securely managed by the **Devise** gem (`devise` ~> 4.9), providing standard functionalities such as sign-up, login, password reset, and session management.

**User Model (`app/models/user.rb`):**
*   `email`: Primary identifier for authentication.
*   `encrypted_password`: Stores hashed passwords.
*   `reset_password_token`, `reset_password_sent_at`, `remember_created_at`: Devise fields for password recovery and session remembrance.
*   `role`: A string column (`admin`, `validator`, or `nil` for general users) used for authorization. (`db/migrate/20240701162533_change_column_name_in_user.rb`)
*   `validator`: A string column to specify which department a validator is assigned to. (`db/migrate/20240422180719_alter_column_in_user_table.rb`)
*   `tab_no`, `nav_tab_no`: Integer columns with default values, likely for tracking multi-page application form progress for a user.
*   `photo` (Active Storage): Allows users to upload a passport-size photograph.
*   `sign` (Active Storage): Allows users to upload their signature.

**Authorization (`app/models/ability.rb`):**
Authorization is implemented using the **CanCanCan** gem (`cancancan` gem).
*   **Admin Role**: Users with `role == 'admin'` have `can :manage, :all`, granting full control over all resources in the system, including access to the RailsAdmin dashboard.
*   **General Users**: Users without an `admin` role or `validator` attribute are restricted from accessing RailsAdmin (`cannot :access, :rails_admin`). Specific abilities for general users (e.g., creating forms, submitting responses) are handled directly in controllers or implicitly through UI elements based on user context.
*   **Validator Role**: Users with the `validator` attribute present are able to access the validation interfaces, allowing them to review credit responses and update eligibility. The `validator` column is a string type which likely holds the department the validator is responsible for.

**Devise Configuration (`config/initializers/devise.rb`):**
*   `config.password_length = 6..128`: Sets password complexity requirements.
*   `config.email_regexp = /\A[^@\s]+@[^@\s]+\z/`: Basic email format validation.
*   `config.strip_whitespace_keys = [:email]`, `config.case_insensitive_keys = [:email]`: Ensures consistent email handling.
*   `config.responder.error_status = :unprocessable_entity`, `config.responder.redirect_status = :see_other`: Hotwire/Turbo specific configuration for Devise responses.

Custom attributes (`photo`, `sign`) are permitted for Devise `sign_up` and `account_update` actions in `ApplicationController#configure_permitted_parameters`.