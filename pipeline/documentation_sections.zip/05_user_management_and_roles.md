## User Management and Roles

The application features a robust user management system with distinct roles and secure authentication.

**Roles Defined:**

*   **Buyer (U)**: Initiates `DocA` and `DocB` documents. (`user_name: 'U'`, `buyer?` method)
*   **Approvers (P, Q, R, S)**: Review and approve/reject documents in a specific sequence. (`user_name: 'P'`, `'Q'`, `'R'`, `'S'`, `approver?` method)
*   **Administrator (admin)**: Manages user details (display name, email, password). (`user_name: 'admin'` or `is_admin: true`, `admin?` method)

**Authentication and Authorization:**

*   **User Model (`app/models/user.rb`)**:
    *   Uses `has_secure_password` for secure password hashing via the `bcrypt` gem.
    *   Validates presence and uniqueness of `user_name` and `email`.
    *   Includes `display_name` and `email` fields.
    *   `is_admin` boolean flag, defaulting to `false`.
    *   Custom helper methods: `buyer?`, `approver?`, `admin?`, `display_name_or_username`.
*   **Sessions Controller (`app/controllers/sessions_controller.rb`)**:
    *   Handles user login (`new`, `create`) and logout (`destroy`).
    *   Authenticates users against `user_name` and `password`.
    *   Stores `user_id` in `session` upon successful login.
    *   Displays all available test users on the login page for convenience.
*   **Application Controller (`app/controllers/application_controller.rb`)**:
    *   `before_action :authenticate_user` ensures that all actions (except login/logout) require a logged-in user.
    *   `current_user` helper method retrieves the logged-in user object.
    *   `check_admin_access` `before_action` restricts access to `/admin` routes to users with `admin?` privileges, redirecting others to the dashboard with an alert.
*   **Admin Controller (`app/controllers/admin_controller.rb`)**:
    *   Provides an interface for administrators to view all users (`index`).
    *   Allows editing user `display_name`, `email`, and `password` (`edit_user`, `update_user`).
    *   Password fields can be left blank during edit to retain the existing password.

**User Class Diagram:**

```mermaid
classDiagram
    class User {
        +String user_id
        +String user_name
        +String password_digest
        +String display_name
        +String email
        +Boolean is_admin
        +DateTime created_at
        +DateTime updated_at
        --
        +has_secure_password
        +has_many doc_as
        +has_many doc_bs
        +validates :user_name, presence, uniqueness
        +validates :password, presence (on: :create)
        +validates :email, presence, format
        +buyer?(): Boolean
        +approver?(): Boolean
        +admin?(): Boolean
        +display_name_or_username(): String
        +authenticate(password): User or nil
    }
    User "1" -- "*" DocA : creates
    User "1" -- "*" DocB : creates
```

**Default User Credentials (from `db/seeds.rb` and `INSTALL_SUMMARY.md`):**

| Username | Display Name   | Email                      | Password  | Role        |
| :------- | :------------- | :------------------------- | :-------- | :---------- |
| `admin`  | Administrator  | admin@gmail.com            | `123456`  | Administrator |
| `U`      | Buyer          | anish.kumbhar04@gmail.com  | `U123`    | Buyer       |
| `P`      | Approver P     | brc@nitk.edu.in            | `P123`    | Approver    |
| `Q`      | Approver Q     | brc@nitk.edu.in            | `Q123`    | Approver    |
| `R`      | Approver R     | brc@nitk.edu.in            | `R123`    | Approver    |
| `S`      | Approver S     | brc@nitk.edu.in            | `S123`    | Approver    |