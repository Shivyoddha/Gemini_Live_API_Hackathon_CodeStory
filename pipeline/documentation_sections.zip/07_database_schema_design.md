## Database Schema Design

The application uses a PostgreSQL database (though `sqlite3` is in `Gemfile` defaults, `docker-compose.yml` and `INSTALL_SUMMARY.md` point to PostgreSQL) with three primary tables: `users`, `doc_as`, and `doc_bs`.

**1. `users` Table:** Stores user authentication and profile information.

| Column Name     | Data Type          | Constraints                            | Description                                          |
| :-------------- | :----------------- | :------------------------------------- | :--------------------------------------------------- |
| `id`            | `bigint`           | `PRIMARY KEY`                          | Auto-incrementing primary key                        |
| `user_id`       | `string`           | `NOT NULL`                             | Unique identifier for the user (e.g., 'u', 'p')      |
| `user_name`     | `string`           | `NOT NULL`, `UNIQUE`, `INDEX`          | Unique username (e.g., 'U', 'P', 'admin')            |
| `password_digest` | `string`           | `NOT NULL`                             | Hashed password using bcrypt                         |
| `display_name`  | `string`           |                                        | User's display name                                  |
| `email`         | `string`           | `INDEX`                                | User's email address                                 |
| `is_admin`      | `boolean`          | `DEFAULT: false`                       | Flag to indicate administrative privileges           |
| `created_at`    | `datetime`         | `NOT NULL`                             | Timestamp of record creation                         |
| `updated_at`    | `datetime`         | `NOT NULL`                             | Timestamp of last record update                      |

**2. `doc_as` Table:** Stores details for Document A and its approval history.

| Column Name     | Data Type             | Constraints                            | Description                                                          |
| :-------------- | :-------------------- | :------------------------------------- | :------------------------------------------------------------------- |
| `id`            | `bigint`              | `PRIMARY KEY`                          | Auto-incrementing primary key                                        |
| `user_id`       | `bigint`              | `NOT NULL`, `FOREIGN KEY (users)`      | Reference to the `User` who created the document                     |
| `eq_id`         | `string`              | `NOT NULL`, `UNIQUE`, `INDEX`          | Unique Equipment ID (e.g., "CSE_1")                                  |
| `name`          | `string`              | `NOT NULL`                             | Equipment name                                                       |
| `cost`          | `decimal(10, 2)`      | `NOT NULL`                             | Cost of the equipment                                                |
| `head`          | `string`              | `NOT NULL`                             | Head of purchase (e.g., "OPC", "IRG")                                |
| `u_date`        | `datetime`            |                                        | Date of processing/forwarding by User U                              |
| `u_remarks`     | `text`                |                                        | Remarks by User U                                                    |
| `p_date`        | `datetime`            |                                        | Date of processing by Approver P                                     |
| `p_remarks`     | `text`                |                                        | Remarks by Approver P                                                |
| `q_date`        | `datetime`            |                                        | Date of processing by Approver Q                                     |
| `q_remarks`     | `text`                |                                        | Remarks by Approver Q                                                |
| `r_date`        | `datetime`            |                                        | Date of processing by Approver R                                     |
| `r_remarks`     | `text`                |                                        | Remarks by Approver R                                                |
| `s_date`        | `datetime`            |                                        | Date of processing by Approver S                                     |
| `s_remarks`     | `text`                |                                        | Remarks by Approver S                                                |
| `status`        | `integer` (`enum`)    | `DEFAULT: 0`                           | Current status of the document (`draft`, `pending_p_approval`, etc.) |
| `created_at`    | `datetime`            | `NOT NULL`                             | Timestamp of record creation                                         |
| `updated_at`    | `datetime`            | `NOT NULL`                             | Timestamp of last record update                                      |

**3. `doc_bs` Table:** Stores details for Document B and its approval history.

| Column Name     | Data Type             | Constraints                            | Description                                                          |
| :-------------- | :-------------------- | :------------------------------------- | :------------------------------------------------------------------- |
| `id`            | `bigint`              | `PRIMARY KEY`                          | Auto-incrementing primary key                                        |
| `user_id`       | `bigint`              | `NOT NULL`, `FOREIGN KEY (users)`      | Reference to the `User` who created the document                     |
| `eq_id`         | `string`              | `NOT NULL`                             | Equipment ID (can be auto-filled from Doc A)                         |
| `name`          | `string`              | `NOT NULL`                             | Equipment name (can be auto-filled from Doc A)                       |
| `cost`          | `decimal(10, 2)`      | `NOT NULL`                             | Cost of the equipment (can be auto-filled from Doc A)                |
| `head`          | `string`              | `NOT NULL`                             | Head of purchase (can be auto-filled from Doc A)                     |
| `proceedings`   | `text`                | `NOT NULL`                             | Specific comments/proceedings for Document B                         |
| `u_date`        | `datetime`            |                                        | Date of processing/forwarding by User U                              |
| `u_remarks`     | `text`                |                                        | Remarks by User U                                                    |
| `p_date`        | `datetime`            |                                        | Date of processing by Approver P                                     |
| `p_remarks`     | `text`                |                                        | Remarks by Approver P                                                |
| `q_date`        | `datetime`            |                                        | Date of processing by Approver Q                                     |
| `q_remarks`     | `text`                |                                        | Remarks by Approver Q                                                |
| `r_date`        | `datetime`            |                                        | Date of processing by Approver R                                     |
| `r_remarks`     | `text`                |                                        | Remarks by Approver R                                                |
| `s_date`        | `datetime`            |                                        | Date of processing by Approver S                                     |
| `s_remarks`     | `text`                |                                        | Remarks by Approver S                                                |
| `status`        | `integer` (`enum`)    | `DEFAULT: 0`                           | Current status of the document (`draft`, `pending_p_approval`, etc.) |
| `created_at`    | `datetime`            | `NOT NULL`                             | Timestamp of record creation                                         |
| `updated_at`    | `datetime`            | `NOT NULL`                             | Timestamp of last record update                                      |

**Status Enum Values (for `doc_as` and `doc_bs`):**

*   `draft`: 0 (Initial state for manually created documents)
*   `pending_p_approval`: 1 (Waiting for Approver P)
*   `pending_q_approval`: 2 (Waiting for Approver Q)
*   `pending_r_approval`: 3 (Waiting for Approver R)
*   `pending_s_approval`: 4 (Waiting for Approver S)
*   `approved`: 5 (Fully approved)
*   `rejected`: 6 (Rejected at any stage)