## Admin and Validator Interfaces
The application provides specialized interfaces for administrators and validators to manage the system and review applications, respectively.

**Administrator Interface (RailsAdmin & Custom Admin Dashboard):**
1.  **RailsAdmin Integration (`rails_admin` gem):**
    *   Accessible via `/admin` route.
    *   **Configuration (`config/initializers/rails_admin.rb`):**
        *   `config.asset_source = :sprockets`: Uses Sprockets for asset serving.
        *   `config.main_app_name = ["FRP Admin", ""]`: Sets the display name for the admin panel.
        *   `config.authenticate_with { warden.authenticate! scope: :user }`: Integrates with Devise for authentication.
        *   `config.current_user_method(&:current_user)`: Defines how to retrieve the current user.
        *   `config.authorize_with :cancancan`: Uses CanCanCan for authorization, ensuring only users with appropriate abilities can access RailsAdmin (specifically `user.role == 'admin'` as defined in `app/models/ability.rb`).
        *   Enables standard actions: `dashboard`, `index`, `new`, `export`, `bulk_delete`, `show`, `edit`, `delete`, `show_in_app`.
    *   **Functionality:** Provides a comprehensive CRUD (Create, Read, Update, Delete) interface for almost all models in the application, including `Users`, `Forms`, `Questions`, `CreditSections`, `CreditQuestions`, `Departments`, `Tabs`, etc. This is the primary tool for system configuration and data management.

2.  **Custom Admin View (`AdminDashboardController#all_responses`):**
    *   Accessible via `/admin_dashboard/all_responses`.
    *   **Purpose:** Offers a specialized dashboard to view all submitted application responses (`Response.all`).
    *   **Filtering:** Includes a JavaScript-enabled department filter, allowing administrators to narrow down responses by the department associated with the form.
    *   **Details Displayed:** Shows Application ID (generated dynamically based on role, department, and response ID), verified credits, a link to view/print the full application PDF, and creation timestamp.
    *   **Action:** Provides a "View Response" button which links to the PDF print view (`print_response_path`).

**Validator Interface (Credit Validation & Eligibility Management):**
1.  **Validator Role Assignment:** Users can be assigned a `validator` role (`string` column in `User` model, intended to store the department they validate for, e.g., "Computer Science"). This allows specific users to validate applications for particular departments.
2.  **Validation Dashboard (`HomeController#validate`):**
    *   Accessible via `/home/validate`.
    *   **Access Control:** Only users with a `validator` attribute can see this menu item in the navigation bar (`partials/_navbar.html.erb`).
    *   **Display:** Lists applications (`Response` objects) that belong to forms associated with the validator's assigned department (`response.form.dept == @user.validator`).
    *   **Details:** Shows Application ID, current Credit Score, Credit Requirement status (Fulfilled/Not Fulfilled/Validation Pending), and final Eligibility status.
    *   **Action:** Provides a "Validate Credit Response" link, leading to the detailed validation view (`responses/validate.html.erb`).
3.  **Detailed Credit Validation (`ResponsesController#validate`):**
    *   Accessible via `/responses/:id/validate`.
    *   **Interface:** Displays a table of all `CreditAnswer`s for a specific application.
    *   **Information per Credit Answer:** Shows the `CreditQuestion` title, applicant's `answer` (count), calculated `credit`, link to view any attached `file_upload`s, and editable fields for `verified_count` and `verified_credit`.
    *   **Dynamic Calculation:** JavaScript updates the `verified_credit` field based on changes to `verified_count` (using `max_credit` and `obt_credit` from the `CreditQuestion`).
    *   **Update Mechanism:** `form_with` is used to allow validators to update individual `CreditAnswer` records. This triggers `CreditAnswersController#update`, which then recalculates the overall `Response#credit_score` using the verified values and sets `Response#validation` to true.
    *   **Remarks and Eligibility (`ResponsesController#add_remark`, `#update_eligibility`):**
        *   Validators can add free-form `remark`s to the overall application response.
        *   They can toggle the `eligibility` status of an application between `true` and `false`. This allows for manual override of eligibility regardless of the calculated credit score.