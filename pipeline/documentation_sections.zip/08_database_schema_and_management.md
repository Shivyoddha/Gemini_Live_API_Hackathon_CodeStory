## Database Schema and Management

The IRIS Procurement Portal uses a **PostgreSQL** database (as indicated by `db/schema.rb`, `INSTALL_SUMMARY.md`, `DOCKER_SETUP.md`, `RENDER_DEPLOYMENT.md`) to store all application data. Although `config/database.yml` shows `sqlite3` as default in development/test, the practical setup uses PostgreSQL.

### Database Schema Overview

The database schema is defined across three main tables: `users`, `doc_as`, and `doc_bs`.

#### 1. `users` Table

Manages user authentication, roles, and contact information.

| Column          | Type      | Constraints                     | Description                                    |
| :-------------- | :-------- | :------------------------------ | :--------------------------------------------- |
| `id`            | `bigint`  | `PRIMARY KEY`                   | Auto-incrementing primary key                  |
| `user_id`       | `string`  | `NOT NULL`                      | Unique identifier (e.g., 'admin', 'u', 'p')    |
| `user_name`     | `string`  | `NOT NULL`, `UNIQUE INDEX`      | Username for login (e.g., 'U', 'P', 'admin')   |
| `password_digest` | `string`  | `NOT NULL`                      | Hashed password using `bcrypt`                 |
| `display_name`  | `string`  | `NULLABLE`                      | User's display name (e.g., 'Buyer', 'Approver P') |
| `email`         | `string`  | `NULLABLE`, `INDEX`             | User's email address                           |
| `is_admin`      | `boolean` | `DEFAULT FALSE`                 | Indicates if user has administrator privileges |
| `created_at`    | `datetime`| `NOT NULL`                      | Timestamp of creation                          |
| `updated_at`    | `datetime`| `NOT NULL`                      | Timestamp of last update                       |

#### 2. `doc_as` Table

Stores details for Document A, including equipment information and its sequential approval history.

| Column          | Type      | Constraints                     | Description                                    |
| :-------------- | :-------- | :------------------------------ | :--------------------------------------------- |
| `id`            | `bigint`  | `PRIMARY KEY`                   | Auto-incrementing primary key                  |
| `user_id`       | `bigint`  | `NOT NULL`, `FOREIGN KEY (users)` | Reference to the `User` who initiated the document |
| `eq_id`         | `string`  | `NOT NULL`, `UNIQUE INDEX`      | Auto-generated Equipment ID (e.g., 'CSE_1')    |
| `name`          | `string`  | `NOT NULL`                      | Equipment name                                 |
| `cost`          | `decimal` | `NOT NULL`, `precision:10, scale:2` | Cost of the equipment                          |
| `head`          | `string`  | `NOT NULL`                      | Head of purchase (e.g., 'Project Fund')        |
| `u_date`        | `datetime`| `NULLABLE`                      | Date of submission by Buyer U                  |
| `u_remarks`     | `text`    | `NULLABLE`                      | Remarks by Buyer U                             |
| `p_date`        | `datetime`| `NULLABLE`                      | Date of approval/rejection by Approver P       |
| `p_remarks`     | `text`    | `NULLABLE`                      | Remarks by Approver P                          |
| `q_date`        | `datetime`| `NULLABLE`                      | Date of approval/rejection by Approver Q       |
| `q_remarks`     | `text`    | `NULLABLE`                      | Remarks by Approver Q                          |
| `r_date`        | `datetime`| `NULLABLE`                      | Date of approval/rejection by Approver R       |
| `r_remarks`     | `text`    | `NULLABLE`                      | Remarks by Approver R                          |
| `s_date`        | `datetime`| `NULLABLE`                      | Date of final approval/rejection by Approver S |
| `s_remarks`     | `text`    | `NULLABLE`                      | Remarks by Approver S                          |
| `status`        | `integer` | `DEFAULT 0`                     | Current status (`draft`, `pending_p_approval`, etc.) |
| `created_at`    | `datetime`| `NOT NULL`                      | Timestamp of creation                          |
| `updated_at`    | `datetime`| `NOT NULL`                      | Timestamp of last update                       |

#### 3. `doc_bs` Table

Stores details for Document B, often auto-generated from Document A, and its sequential approval history.

| Column          | Type      | Constraints                     | Description                                    |
| :-------------- | :-------- | :------------------------------ | :--------------------------------------------- |
| `id`            | `bigint`  | `PRIMARY KEY`                   | Auto-incrementing primary key                  |
| `user_id`       | `bigint`  | `NOT NULL`, `FOREIGN KEY (users)` | Reference to the `User` who initiated the document (or Doc A's user) |
| `eq_id`         | `string`  | `NOT NULL`                      | Equipment ID (auto-filled from Doc A)          |
| `name`          | `string`  | `NOT NULL`                      | Equipment name (auto-filled from Doc A)        |
| `cost`          | `decimal` | `NOT NULL`, `precision:10, scale:2` | Cost of the equipment (auto-filled from Doc A) |
| `head`          | `string`  | `NOT NULL`                      | Head of purchase (auto-filled from Doc A)      |
| `proceedings`   | `text`    | `NOT NULL`                      | Additional comments/proceedings for Doc B      |
| `u_date`        | `datetime`| `NULLABLE`                      | Date of submission by Buyer U                  |
| `u_remarks`     | `text`    | `NULLABLE`                      | Remarks by Buyer U                             |
| `p_date`        | `datetime`| `NULLABLE`                      | Date of approval/rejection by Approver P       |
| `p_remarks`     | `text`    | `NULLABLE`                      | Remarks by Approver P                          |
| `q_date`        | `datetime`| `NULLABLE`                      | Date of approval/rejection by Approver Q       |
| `q_remarks`     | `text`    | `NULLABLE`                      | Remarks by Approver Q                          |
| `r_date`        | `datetime`| `NULLABLE`                      | Date of approval/rejection by Approver R       |
| `r_remarks`     | `text`    | `NULLABLE`                      | Remarks by Approver R                          |
| `s_date`        | `datetime`| `NULLABLE`                      | Date of final approval/rejection by Approver S |
| `s_remarks`     | `text`    | `NULLABLE`                      | Remarks by Approver S                          |
| `status`        | `integer` | `DEFAULT 0`                     | Current status (`draft`, `pending_p_approval`, etc.) |
| `created_at`    | `datetime`| `NOT NULL`                      | Timestamp of creation                          |
| `updated_at`    | `datetime`| `NOT NULL`                      | Timestamp of last update                       |

### Database Management

*   **Migrations (`db/migrate/`)**: A series of `ActiveRecord::Migration` files track all schema changes. These include `create_users`, `create_doc_as`, `create_doc_bs`, `add_email_and_admin_fields_to_users`, and `remove_unique_email_constraint`. They ensure an incremental and version-controlled evolution of the database schema.
*   **Seeding (`db/seeds.rb`)**: A seeding script populates the `users` table with initial data, including the 'admin' user and the Buyer/Approver users (U, P, Q, R, S) with their default passwords and emails. This is essential for setting up a development or test environment.
*   **Rake Tasks**: Standard Rails Rake tasks like `db:create`, `db:migrate`, `db:seed`, and `db:drop` are used for database management, often orchestrated by `bin/setup` and `bin/update` scripts.
*   **`db/schema.rb`**: This file is an auto-generated representation of the current state of the database schema, reflecting the outcome of all applied migrations.

### Class Diagram

```mermaid
classDiagram
    direction LR
    class User {
        +bigint id
        +string user_id
        +string user_name
        +string password_digest
        +string display_name
        +string email
        +boolean is_admin
        +datetime created_at
        +datetime updated_at
        +has_secure_password
        +buyer?(): boolean
        +approver?(): boolean
        +admin?(): boolean
        +display_name_or_username(): string
    }

    class DocA {
        +bigint id
        +bigint user_id
        +string eq_id
        +string name
        +decimal cost
        +string head
        +datetime u_date
        +text u_remarks
        +datetime p_date
        +text p_remarks
        +datetime q_date
        +text q_remarks
        +datetime r_date
        +text r_remarks
        +datetime s_date
        +text s_remarks
        +integer status
        +datetime created_at
        +datetime updated_at
        +enum status
        +next_status(): Symbol
        +approve!(user_name): void
        +reject!(remarks): void
    }

    class DocB {
        +bigint id
        +bigint user_id
        +string eq_id
        +string name
        +decimal cost
        +string head
        +text proceedings
        +datetime u_date
        +text u_remarks
        +datetime p_date
        +text p_remarks
        +datetime q_date
        +text q_remarks
        +datetime r_date
        +text r_remarks
        +datetime s_date
        +text s_remarks
        +integer status
        +datetime created_at
        +datetime updated_at
        +enum status
        +next_status(): Symbol
        +approve!(user_name): void
        +reject!(remarks): void
    }

    class AutoCreateDocBService {
        -DocA doc_a
        -User user
        +call(): DocB
    }

    User "1" -- "*" DocA : has
    User "1" -- "*" DocB : has
    AutoCreateDocBService "1" -- "1" DocA : operates_on
    AutoCreateDocBService "1" -- "1" User : context_of
```