## Dynamic Form & Questionnaire System
The application features a robust dynamic form and questionnaire system, allowing administrators to create highly customizable multi-page application forms.

**Core Models and Relationships:**
*   **`Form` (`app/models/form.rb`, `forms` table):** Represents a job application form.
    *   `name`, `role`, `salary`, `dept`, `description`: Basic job/form details.
    *   `fee`: Application fee.
    *   `credit_req`: Minimum credit score required for the application.
    *   `template_form_id`: Allows creating new forms based on existing templates.
    *   `belongs_to :user`: An administrator user creates the form.
    *   `has_many :questions, dependent: :destroy`: Forms contain multiple questions, ordered by `position`.
    *   `has_many :responses, dependent: :destroy`: Forms collect multiple responses.
    *   `apply_template(template_form_id)` method: Copies questions and options from a template form.

*   **`Tab` (`app/models/tab.rb`, `tabs` table):** Organizes questions into logical sections for multi-page forms.
    *   `title`: Title of the tab (e.g., "Personal Information", "Education").
    *   `has_many :questions, dependent: :destroy`: Tabs contain questions, ordered by `position`.
    *   `tab_no` (in `users` table): Tracks the current tab an applicant is on.

*   **`Question` (`app/models/question.rb`, `questions` table):** Individual questions within a form or tab.
    *   `title`: The question text.
    *   `position`: Integer field for ordering questions within a form or tab (uses `acts_as_list`).
    *   `role`: String field, likely for conditional display (e.g., 'O' for optional, 'C' for conditional trigger, 'R' for readonly, 'S' for scoring/date source in tabular inputs).
    *   `belongs_to :form`, `belongs_to :question_type`, `belongs_to :tab`: Associates a question with its parent form/tab and its type.
    *   `has_many :options, dependent: :destroy`: For multiple-choice questions.
    *   `has_many :answers, dependent: :destroy`: Stores submitted answers.
    *   `accepts_nested_attributes_for :options`: Allows creating/updating options directly when creating/updating questions.

*   **`QuestionType` (`app/models/question_type.rb`, `question_types` table):** Defines the type of input expected for a question.
    *   `title`: (e.g., "Text Input", "Text Area", "Radio Button", "Checkbox", "Number Field", "Tabular Input", "Date Field", "File Upload").
    *   `has_many :question, dependent: :destroy`: One question type can be used by many questions.

*   **`Option` (`app/models/option.rb`, `options` table):** Choices for multiple-choice or checkbox questions.
    *   `title`: The option text.
    *   `role`: String field, similar to question role, for specific behavior in tabular inputs (e.g., 'R' for read-only, 'S' for source of date).
    *   `belongs_to :question`: An option belongs to a question.

*   **`Response` (`app/models/response.rb`, `responses` table):** An applicant's complete submission to a `Form`.
    *   `title` (typically applicant's email).
    *   `credit_score`: Calculated credit score.
    *   `validation`, `remark`, `eligibility`: Fields for credit validation.
    *   `payment_status`, `amount`: Payment details.
    *   `profile_response`: Boolean flag to distinguish application profile responses from job-specific application responses.
    *   `app_no`: Application number.
    *   `belongs_to :form`, `belongs_to :user`: A response is for a specific form by a specific user.
    *   `has_many :answers, dependent: :destroy`, `has_many :credit_answers, dependent: :destroy`, `has_many :file_uploads, dependent: :destroy`: Collects all parts of a response.
    *   `accepts_nested_attributes_for :answers`: Allows creating/updating answers directly when creating/updating responses.

*   **`Answer` (`app/models/answer.rb`, `answers` table):** Stores a single answer to a `Question`.
    *   `content`: The submitted answer (string, can store JSON-like array for multi-select/tabular).
    *   `has_one_attached :file`: For file upload question types.
    *   `belongs_to :question`, `belongs_to :response`.

**Form Creation and Submission Flow:**
1.  **Admin (`FormsController#new`, `#create`):** An administrator creates a new form, defining its name, role, salary, department, credit requirement, and fee. They can also select a template form to pre-populate questions.
2.  **Question Management (`FormsController#show`, `QuestionsController`):** From the form's detail page, the admin can add new questions, specify their type (text, radio, checkbox, etc.), and add options if applicable. Questions can be reordered using `moveup` and `movedown` actions (utilizing `acts_as_list`).
3.  **Applicant Profile (`HomeController#app_profile`):** Users (applicants) fill out a multi-tabbed "Application Profile" (represented by `Response` with `profile_response: true`). The `User#tab_no` and `User#nav_tab_no` attributes track their progress through these tabs.
4.  **Application Submission (`FormsController#submit_form`, `#update_response`):** Once an applicant meets the profile requirements (or if there are none), they can apply for a specific job form. This involves filling out the questions defined in that form. Answers are stored in the `Answer` model. For tabular inputs (QuestionType 6), JavaScript dynamically adds rows and calculates differences between 'S' (start/end date) roles to populate 'R' (read-only duration) roles.
5.  **Data Storage:** Answers are serialized/stored in the `content` column of the `Answer` model, handling various types including arrays for checkboxes and tabular inputs.