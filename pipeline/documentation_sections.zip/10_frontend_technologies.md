## Frontend Technologies
The application's frontend is crafted to provide a responsive and dynamic user experience, leveraging a combination of modern and traditional web technologies.

**Core Technologies:**
*   **Bootstrap (v5.3.2):**
    *   Provides a responsive design framework for styling UI components. Evident from `bootstrap` dependency in `package.json`, `application.bootstrap.scss` in `app/assets/stylesheets`, and extensive use of Bootstrap classes (e.g., `container`, `row`, `col-md-6`, `btn`, `form-control`, `card`, `navbar`) across almost all views (`app/views`).
*   **Hotwire (Turbo & Stimulus):**
    *   **Turbo Rails (v7.3.0):** Enhances page navigation by intercepting link clicks and form submissions, fetching content via AJAX, and replacing only the `<body>` (or specified `turbo-frame`) without full page reloads. This provides a Single Page Application (SPA)-like experience, as seen in `app/javascript/application.js` and `Gemfile`.
    *   **Stimulus Rails (v3.2.2):** A modest JavaScript framework for adding behavior to HTML. It connects JavaScript controllers directly to HTML elements using `data-controller` and `data-action` attributes. `app/javascript/controllers/application.js` and `app/javascript/controllers/hello_controller.js` are present, indicating a foundational setup.
*   **Sass (SCSS):**
    *   Used for CSS preprocessing, allowing for variables, nesting, and mixins to write more maintainable stylesheets. `sass` dependency in `package.json` and `sassc-rails` gem confirm its use. Stylesheets like `admin_dashboard.scss`, `credit_answers.scss` follow the SCSS syntax. The main Bootstrap styling is handled by `application.bootstrap.scss`.
*   **PostCSS with Autoprefixer:**
    *   `postcss` and `autoprefixer` are used to process CSS, specifically to add vendor prefixes to CSS rules, ensuring compatibility across different browsers. This is configured in the `package.json` scripts (`build:css:prefix`).
*   **ESBuild (v0.19.5):**
    *   A fast JavaScript bundler used to compile and bundle JavaScript code. The `package.json` `build` script (`esbuild app/javascript/*.* --bundle --sourcemap --outdir=app/assets/builds --public-path=/assets`) indicates that ESBuild is responsible for processing JavaScript assets.
*   **JavaScript (Vanilla & jQuery):**
    *   While Hotwire is the primary framework for interactivity, vanilla JavaScript is used for specific dynamic behaviors, such as adding/deleting rows in tabular inputs (`app/views/forms/_form.html.erb`, `app/views/forms/submit_form.html.erb`, `app/views/home/app_profile.html.erb`), dynamic calculation of credit scores (`app/views/credit_answers/new.html.erb`, `app/views/responses/my_credit.html.erb`), and filtering/truncating text (`app/views/home/index.html.erb`, `app/views/admin_dashboard/all_responses.html.erb`).
    *   jQuery is included via CDN in `app/views/layouts/application.html.erb`, suggesting it might be used for legacy components or specific libraries, although Hotwire generally aims to reduce direct DOM manipulation with jQuery.

**Asset Pipeline Integration:**
*   **`jsbundling-rails` & `cssbundling-rails` gems:** These gems integrate external JavaScript and CSS bundlers (ESBuild for JS, Sass/PostCSS for CSS) into the Rails asset pipeline.
*   **`Procfile.dev`:** Defines development processes: `js: yarn build --watch` and `css: yarn watch:css` ensure that JavaScript and CSS assets are continuously rebuilt upon changes.
*   **`manifest.js`:** Links the asset trees and specific stylesheets (`auth.css`, `home.css`, etc.) and the main `application.js` entry point.

**Styling Strategy:**
The application uses a mix of global stylesheets (`application.scss`) and component-specific CSS files (e.g., `auth.css`, `appprofile.css`, `credits.css`, `navbar.css`) to manage its visual design, all built upon Bootstrap. Font imports (`Jost`, `Gabarito`, `Quicksand`) are used for custom typography.