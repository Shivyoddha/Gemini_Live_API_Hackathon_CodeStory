# Traveller Application Documentation

## Project Overview
The Traveller repository hosts a Ruby on Rails web application designed to facilitate travel planning, package booking, and feedback submission. It provides core functionalities for users to explore available travel packages, manage their bookings, and rate their experiences. Additionally, it includes an administrative interface for managing the application's core data, such as travel packages and companies.

## Business Value
The Traveller application aims to enhance user comfort and organization in travel planning by offering a centralized platform. It simplifies the process of discovering and booking holiday packages, allowing users to track their bookings efficiently. A key feature is the ability to collect valuable feedback on companies, which provides crucial insights for continuous service improvement and helps other users make informed decisions, thereby streamlining the overall travel experience.

## System Architecture
The Traveller application is built on the Ruby on Rails 7.0.4 framework, adhering to the Model-View-Controller (MVC) architectural pattern. It uses Ruby 3.1.3.

### Core Components:
*   **Web Server**: Puma (~> 5.0) is configured as the web server, serving HTTP requests.
*   **Database**: MySQL (~> 0.5) is used for persistent data storage, managed through ActiveRecord, Rails' object-relational mapping (ORM) layer. Database configuration is specified in `config/database.yml`.
*   **Frontend**: The frontend leverages modern web technologies to provide a responsive and dynamic user experience:
    *   **Frameworks**: Hotwire (Turbo and Stimulus) for SPA-like navigation and dynamic content.
    *   **Styling**: Bootstrap 5.2.3 and custom Sass/CSS (`app/assets/stylesheets/application.bootstrap.scss`, `login.css`, `about.css`) for responsive design and UI components. Bootstrap Icons are also integrated.
    *   **Bundling**: `jsbundling-rails` uses Esbuild (^0.17.18) for JavaScript bundling, while `cssbundling-rails` uses Sass (^1.62.1) for CSS preprocessing, as defined in `package.json` and `Procfile.dev`.
*   **Background Jobs**: Basic Active Job functionality is included, though no specific job implementations are present (`app/jobs/application_job.rb`).
*   **Real-time Features**: Action Cable is part of the Rails framework, with an `async` adapter for development and `redis` for production in `config/cable.yml`, suggesting potential for real-time features.
*   **Email Handling**: Action Mailer is configured for sending emails, such as those related to Devise user management (`app/mailers/application_mailer.rb`).

### Technology Stack:
| Category          | Technology       | Version/Gem       | Purpose                                                    | Evidence                                                       |
| :---------------- | :--------------- | :---------------- | :--------------------------------------------------------- | :--------------------------------------------------------------- |
| **Backend**       | Ruby             | 3.1.3             | Programming Language                                       | `.ruby-version`, `Gemfile`                                       |
|                   | Rails            | ~> 7.0.4          | Web Application Framework (MVC)                            | `Gemfile`                                                        |
|                   | Puma             | ~> 5.0            | Web Server                                                 | `Gemfile`, `Procfile.dev`, `config/puma.rb`                      |
|                   | MySQL            | ~> 0.5            | Relational Database                                        | `Gemfile` (mysql2), `config/database.yml`                        |
|                   | ActiveRecord     | Rails built-in    | ORM for database interactions                              | `app/models/application_record.rb`, `db/schema.rb`               |
|                   | Action Mailer    | Rails built-in    | Email capabilities                                         | `app/mailers/application_mailer.rb`                              |
|                   | Action Cable     | Rails built-in    | Real-time communication                                    | `app/channels/`, `config/cable.yml`                              |
|                   | Active Job       | Rails built-in    | Background job processing                                  | `app/jobs/application_job.rb`                                    |
| **Authentication**| Devise           | latest            | User authentication and session management                 | `Gemfile`, `config/initializers/devise.rb`, `app/controllers/application_controller.rb` |
| **Admin Panel**   | Rails Admin      | latest            | Administrative interface for data management               | `Gemfile`, `config/routes.rb`, `config/initializers/rails_admin.rb` |
| **API**           | Jbuilder         | latest            | JSON API generation and serialization                      | `Gemfile`, `app/views/**/*.json.jbuilder`                        |
| **Frontend**      | HTML/CSS         |                   | Core Markup & Styling                                      | `app/views/`, `app/assets/stylesheets/`                          |
|                   | JavaScript       |                   | Frontend interactivity                                     | `app/assets/javascript/`                                         |
|                   | Hotwire (Turbo)  | ~> 7.3.0          | Fast page navigation, partial rendering                    | `Gemfile` (turbo-rails), `package.json`                          |
|                   | Hotwire (Stimulus)| ~> 3.2.1          | Modest JavaScript framework                                | `Gemfile` (stimulus-rails), `package.json`, `app/assets/javascript/controllers/` |
|                   | Bootstrap        | ~> 5.2.3          | Responsive UI Framework                                    | `package.json`, `app/assets/stylesheets/application.bootstrap.scss` |
|                   | Bootstrap Icons  | ~> 1.10.5         | Icon library                                               | `package.json`, `app/assets/stylesheets/application.bootstrap.scss` |
|                   | Sass             | ~> 1.62.1         | CSS Preprocessor                                           | `package.json`, `Gemfile` (sassc-rails)                          |
|                   | Esbuild          | ~> 0.17.18        | JavaScript Bundler                                         | `package.json`, `jsbundling-rails`                               |

## User Authentication & Account Management
User authentication and account management are comprehensively handled by the Devise gem.

### Key Features:
*   **User Registration**: Users can sign up with `email`, `password`, `name`, `homelocation`, and `phoneno`. The `application_controller.rb` includes a `before_action :configure_permitted_parameters` to permit these custom attributes during sign-up and account updates.
*   **Login/Logout**: Standard email and password-based login and secure logout functionality are provided. The root path is configured to redirect to the Devise sign-in page.
*   **Password Recovery**: Functionality for users to reset forgotten passwords via email is included.
*   **Email/Password Change**: Users can update their email and password, with options for reconfirmation if configured (`config/initializers/devise.rb`).
*   **Error Handling**: Devise's built-in error messages are utilized for user feedback during authentication processes.
*   **Session Management**: User sessions are managed by Devise. After successful sign-in, users are redirected to `home_index_path` as defined in `ApplicationController`.
*   **Views**: All Devise-related views are located under `app/views/devise/`, including custom styling for the login page (`app/views/devise/sessions/new.html.erb` links `login.css`).

## Domain Model & Relationships
The application's core entities are represented by the following ActiveRecord models, with their relationships defined:

```mermaid
classDiagram
    class User {
        +String email
        +String encrypted_password
        +String name
        +String homelocation
        +String phoneno
        +has_many slots
        +has_many feedbacks
    }
    class Company {
        +String companyname
        +String hqlocation
        +Integer rating
        +has_many trippackages
        +has_many feedbacks
    }
    class Trippackage {
        +String package_name
        +String destination
        +DateTime departure
        +DateTime arrival
        +Integer budget
        +Text description
        +String travelfrom
        +Integer noofbookings
        +String packcountry
        +belongs_to company
        +has_many slots
    }
    class Slot {
        +DateTime bookingtime
        +belongs_to user
        +belongs_to trippackage
    }
    class Feedback {
        +Integer rate
        +Text descr
        +belongs_to user
        +belongs_to company
    }

    User "1" -- "0..*" Slot : books
    User "1" -- "0..*" Feedback : provides
    Company "1" -- "0..*" Trippackage : offers
    Company "1" -- "0..*" Feedback : receives
    Trippackage "1" -- "0..*" Slot : has
    Slot "0..*" -- "1" User
    Slot "0..*" -- "1" Trippackage
    Feedback "0..*" -- "1" User
    Feedback "0..*" -- "1" Company
    Trippackage "0..*" -- "1" Company
```

### Model Descriptions and Attributes:

*   **`User`**: Represents an individual user of the application.
    *   **Attributes**: `email`, `encrypted_password`, `reset_password_token`, `reset_password_sent_at`, `remember_created_at`, `created_at`, `updated_at`, `name`, `homelocation`, `phoneno`.
    *   **Relationships**: `has_many :slots`, `has_many :feedbacks`.
*   **`Company`**: Represents a travel company offering packages.
    *   **Attributes**: `companyname`, `hqlocation`, `rating`, `created_at`, `updated_at`.
    *   **Relationships**: `has_many :trippackages`, `has_many :feedbacks`.
*   **`Trippackage`**: Represents a specific travel package.
    *   **Attributes**: `package_name`, `destination`, `departure`, `arrival`, `budget`, `description`, `created_at`, `updated_at`, `travelfrom`, `noofbookings`, `packcountry`.
    *   **Relationships**: `has_many :slots`, `belongs_to :company`.
*   **`Slot`**: Represents a booking instance for a `Trippackage` by a `User`.
    *   **Attributes**: `bookingtime`, `created_at`, `updated_at`.
    *   **Relationships**: `belongs_to :user`, `belongs_to :trippackage`.
*   **`Feedback`**: Represents user feedback on a `Company`.
    *   **Attributes**: `rate`, `descr`, `created_at`, `updated_at`.
    *   **Relationships**: `belongs_to :user`, `belongs_to :company`.

## Frontend Architecture
The Traveller application's frontend is engineered for a modern, interactive web experience, built primarily with a combination of standard web technologies and advanced Rails features.

### Core Technologies:
*   **HTML & ERB**: Views are rendered using Embedded Ruby (ERB) templates (`.html.erb` files in `app/views/`).
*   **CSS & Sass**:
    *   **Bootstrap 5.2.3**: Provides a robust, responsive design framework for UI components (`application.bootstrap.scss` imports Bootstrap's SASS files).
    *   **Custom Styles**: Dedicated stylesheets like `login.css` and `about.css` are used for specific page layouts and custom design elements, complementing the Bootstrap framework.
    *   **Sass**: `sassc-rails` gem and `sass` npm package (`package.json`) are used for CSS preprocessing, allowing for more organized and maintainable stylesheets.
*   **JavaScript**:
    *   **Hotwire (Turbo)**: `@hotwired/turbo-rails` enables fast page navigation, form submissions, and partial updates without full page reloads, providing a Single Page Application (SPA)-like feel.
    *   **Hotwire (Stimulus)**: `@hotwired/stimulus` is a lightweight JavaScript framework for adding interactivity to HTML. Controllers are found in `app/assets/javascript/controllers/`, with a `hello_controller.js` as an example.
    *   **Bootstrap JavaScript**: `@popperjs/core` and `bootstrap` npm packages provide interactive Bootstrap components (e.g., carousels, dropdowns).
*   **Asset Bundling**:
    *   `jsbundling-rails` integrates `esbuild` for efficiently bundling and transpiling JavaScript assets into `app/assets/builds`.
    *   `cssbundling-rails` integrates `sass` to compile Sass stylesheets into CSS, also outputting to `app/assets/builds`.
    *   The `Procfile.dev` explicitly defines `js: yarn build --watch` and `css: yarn build:css --watch` commands, indicating continuous development-time compilation.
*   **Asset Pipeline Integration**: `app/assets/config/manifest.js` links various asset types, including images, built assets (`builds`), the main JavaScript entry point (`application.js`), and custom CSS files (`login.css`, `about.css`).

The use of Hotwire minimizes the need for extensive custom JavaScript, focusing on server-rendered HTML with progressive enhancements for dynamic interactions.

## Administrative Panel
The application incorporates a dedicated administrative panel to manage its underlying data and resources efficiently.

### Implementation Details:
*   **Gem**: The administrative interface is powered by the `rails_admin` gem.
*   **Mount Point**: It is mounted at the `/admin` URL path, as configured in `config/routes.rb`: `mount RailsAdmin::Engine => '/admin', as: 'rails_admin'`.
*   **Configuration**: Basic configuration is present in `config/initializers/rails_admin.rb`, which includes standard actions like `dashboard`, `index`, `new`, `edit`, `delete`, `show`, `export`, `bulk_delete`, and `show_in_app`.
*   **Functionality**: This panel allows authorized administrators to perform full CRUD (Create, Read, Update, Delete) operations on models such as `Trippackages` and `Companies`, as evidenced by views like `app/views/mainportal/admindashboard.html.erb` which provides links to "Create new package" and "View existing packages". While `rails_admin` inherently provides management for all registered ActiveRecord models, the dashboard specifically highlights package management.

## JSON API Endpoints
The Traveller application provides JSON API endpoints for its primary resources, enabling external or programmatic access to data. This is facilitated by the `jbuilder` gem for efficient and flexible JSON serialization.

### Implemented Endpoints:
The following resources expose JSON endpoints, alongside their standard HTML views:

*   **Companies**:
    *   `GET /companies.json`: Lists all companies.
    *   `GET /companies/:id.json`: Retrieves details for a specific company.
    *   `app/views/companies/_company.json.jbuilder`: Defines the structure for a single company object.
    *   `app/views/companies/index.json.jbuilder`: Defines the structure for a collection of companies.
*   **Feedbacks**:
    *   `GET /feedbacks.json`: Lists all feedbacks.
    *   `GET /feedbacks/:id.json`: Retrieves details for a specific feedback.
    *   `app/views/feedbacks/_feedback.json.jbuilder`: Defines the structure for a single feedback object.
    *   `app/views/feedbacks/index.json.jbuilder`: Defines the structure for a collection of feedbacks.
*   **Slots**:
    *   `GET /slots.json`: Lists all booking slots.
    *   `GET /slots/:id.json`: Retrieves details for a specific slot.
    *   `app/views/slots/_slot.json.jbuilder`: Defines the structure for a single slot object.
    *   `app/views/slots/index.json.jbuilder`: Defines the structure for a collection of slots.
*   **Trippackages**:
    *   `GET /trippackages.json`: Lists all travel packages.
    *   `GET /trippackages/:id.json`: Retrieves details for a specific travel package.
    *   `app/views/trippackages/_trippackage.json.jbuilder`: Defines the structure for a single travel package object.
    *   `app/views/trippackages/index.json.jbuilder`: Defines the structure for a collection of travel packages.

These endpoints allow data consumers to interact with the application's resources using standard RESTful conventions, returning data formatted according to the `.jbuilder` templates.