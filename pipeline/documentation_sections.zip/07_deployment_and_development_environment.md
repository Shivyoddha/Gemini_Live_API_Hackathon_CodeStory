## Deployment and Development Environment

The IRIS Procurement Portal is designed for flexible deployment, supporting both a containerized local development setup using Docker and a production deployment target like Render.

### Local Development Environment

#### Standard Local Setup (without Docker)

The application can be run directly on a host system with Ruby and PostgreSQL installed.

**Prerequisites**:
*   Ruby 3.2.2+
*   PostgreSQL
*   Bundler gem

**Installation Steps (from `README.md`, `INSTALL_SUMMARY.md`, `SETUP_INSTRUCTIONS.md`)**:
1.  Install Ruby, PostgreSQL, and Bundler.
2.  Set up PostgreSQL user and databases:
    ```sql
    CREATE USER iris_prototype WITH PASSWORD 'your_password';
    CREATE DATABASE iris_prototype_development OWNER iris_prototype;
    CREATE DATABASE iris_prototype_test OWNER iris_prototype;
    ```
3.  Navigate to project directory, install gems: `bundle install`.
4.  Initialize database: `rails db:create`, `rails db:migrate`, `rails db:seed`.
5.  Start server: `rails server` or `bundle exec rails s`.
6.  Access at `http://localhost:3000`.

**Helper Scripts (`bin/`)**:
*   `bin/setup`: Automates installation of dependencies, drops/creates/migrates the database, and seeds initial data.
*   `bin/update`: Installs/updates gems, runs migrations, updates storage, clears logs, and restarts the application.
*   `bin/rails`, `bin/bundle`, `bin/rake`: Standard Rails executable wrappers.

#### Docker-based Development Environment

A Docker-based setup ensures a consistent development environment, isolating the application and its dependencies.

**Prerequisites (from `DOCKER_SETUP.md`)**:
*   Docker Desktop (includes Docker Compose)

**Quick Start (from `DOCKER_SETUP.md`)**:
1.  Clone repository.
2.  `docker-compose up` to build and start services.
3.  `docker-compose exec web rails db:create`, `rails db:migrate`, `rails db:seed` to set up the database within the container.
4.  Access at `http://localhost:3000`.

**Docker Configuration**:
*   **`Dockerfile`**: Defines the Rails application image, based on `ruby:3.2.0`. It installs Node.js, `build-essential`, `sqlite3` (though PostgreSQL is preferred for runtime), Bundler, copies the Gemfile, installs gems, copies the application code, and exposes port `3000`. The default command is `rails server -b 0.0.0.0`.
*   **`docker-compose.yml`**: Orchestrates two services:
    *   `web`: Builds from `Dockerfile`, mounts the application directory (`.:/app`), maps port `3000`, and sets `RAILS_ENV=development`. It also passes `GMAIL_USERNAME` and `GMAIL_PASSWORD` environment variables, with default values.
    *   `db`: (Implicitly used by the `DOCKER_SETUP.md` documentation mentioning `psql` access, although no `db` service is explicitly defined in the `docker-compose.yml`. This implies a local/separate PostgreSQL setup or an omitted `db` service from the provided `docker-compose.yml` snippet. *Correction: The `docker-compose.yml` actually only defines `web` and mentions `bundle_cache` volume. The `DOCKER_SETUP.md` section "Access database directly" references `docker-compose exec db psql...` indicating that a `db` service *should* exist, or it's an instruction assuming a broader `docker-compose.yml` than provided. Given the instruction to `docker-compose up`, the Rails app needs a DB, and `DOCKER_SETUP.md` mentions "Orchestrates Rails app + PostgreSQL". I will assume it means PostgreSQL for `db` service.)`
    *   `volumes`: `bundle_cache` is used to cache gems between builds.

### Production Deployment (Render)

The application is configured for deployment on Render, a cloud platform.

**Render Configuration (from `RENDER_DEPLOYMENT.md`, `render.yaml`, `Procfile`)**:
*   **`render.yaml`**: Defines a `web` service:
    *   `env: ruby`
    *   `buildCommand`: `bundle install && bundle exec rails db:migrate RAILS_ENV=production && bundle exec rails db:seed` - ensures dependencies, schema, and initial data are set up.
    *   `startCommand`: `bundle exec rails server -p ${PORT:-3000}` - uses the `Procfile` command.
    *   **Environment Variables**: Requires `DATABASE_URL` (provided by Render), `RAILS_ENV=production`, `SECRET_KEY_BASE` (auto-generated), `RAILS_MASTER_KEY` (synced manually), `GMAIL_USERNAME`, `GMAIL_PASSWORD`, and `APP_HOST` (synced manually).
*   **`Procfile`**: Specifies the command to start the web server in production: `web: bundle exec rails server -p ${PORT:-3000}`.
*   **`config/environments/production.rb`**: Configures production-specific settings, including `config.active_job.queue_adapter = :inline`, `config.log_level = :info`, and SMTP settings that rely on `ENV['GMAIL_USERNAME']` and `ENV['GMAIL_PASSWORD']`.