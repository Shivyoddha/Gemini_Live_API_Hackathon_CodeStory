## Procurement Workflow Design

The system implements a structured, sequential approval process for two types of documents: Document A and Document B.

### Document A Workflow

Document A is initiated by a Buyer (User U) and progresses through a fixed chain of four Approvers (P, Q, R, S).

**Stages and Transitions:**

1.  **Initiation (User U)**:
    *   Buyer (U) logs in and creates a new Document A, providing `name`, `cost`, `head`, and initial `u_remarks`.
    *   `eq_id` is automatically generated (e.g., `CSE_1`).
    *   Upon submission, `u_date` is recorded, and the document status changes to `pending_p_approval`.
    *   An email notification is sent to Approver P.
2.  **Approver P's Review**:
    *   Approver P logs in, sees the document pending their approval on the dashboard.
    *   P reviews the document, adds `p_remarks`, and chooses to "Approve" or "Reject".
    *   **Approve**: `p_date` is recorded, status changes to `pending_q_approval`. Emails are sent to User U (status update) and Approver Q (new approval request).
    *   **Reject**: `p_date` is recorded, status changes to `rejected`. An email is sent to User U with the rejection reason.
3.  **Approver Q's Review**:
    *   Similar to P, Q reviews, adds `q_remarks`.
    *   **Approve**: `q_date` is recorded, status changes to `pending_r_approval`. Emails sent to U and R.
    *   **Reject**: `q_date` is recorded, status changes to `rejected`. Email sent to U.
4.  **Approver R's Review**:
    *   Similar to P, R reviews, adds `r_remarks`.
    *   **Approve**: `r_date` is recorded, status changes to `pending_s_approval`. Emails sent to U and S.
    *   **Reject**: `r_date` is recorded, status changes to `rejected`. Email sent to U.
5.  **Approver S's Review (Final Document A Approval)**:
    *   Approver S reviews, adds `s_remarks`.
    *   **Approve**: `s_date` is recorded, status changes to `approved`. An email is sent to User U (final approval).
        *   **Automatic Trigger**: Immediately upon S's approval, `AutoCreateDocBService` is invoked to create Document B.
    *   **Reject**: `s_date` is recorded, status changes to `rejected`. Email sent to U.

### Document B Workflow

Document B is either auto-generated upon Document A's full approval or can be manually initiated. It follows an identical sequential approval chain (P, Q, R, S) as Document A.

**Stages and Transitions (Similar to Document A):**

1.  **Initiation (Auto-generated or User U)**:
    *   If auto-generated from Doc A: `eq_id`, `name`, `cost`, `head` are pre-filled. `proceedings` is set to "Auto-generated after Document A approval" and `u_remarks` as "Auto-initiated after Document A approval". Status is `draft`.
    *   If manually created by Buyer (U): U fills `name`, `cost`, `head`, `proceedings`, and `u_remarks`. `eq_id` is auto-generated.
    *   Upon initiation, `u_date` is recorded, and status changes to `pending_p_approval`.
    *   An email notification is sent to Approver P.
2.  **Approver P's Review**: Approves (`p_date` recorded, status `pending_q_approval`, emails to U and Q) or Rejects (`p_date` recorded, status `rejected`, email to U).
3.  **Approver Q's Review**: Approves (`q_date` recorded, status `pending_r_approval`, emails to U and R) or Rejects (`q_date` recorded, status `rejected`, email to U).
4.  **Approver R's Review**: Approves (`r_date` recorded, status `pending_s_approval`, emails to U and S) or Rejects (`r_date` recorded, status `rejected`, email to U).
5.  **Approver S's Review (Final Document B Approval)**: Approves (`s_date` recorded, status `approved`, email to U) or Rejects (`s_date` recorded, status `rejected`, email to U).

Each approval or rejection step captures the date and remarks specific to the approver. The system ensures that only the current designated approver can take action on a document.

**Procurement Workflow Sequence Diagram (Document A Example):**

```mermaid
sequenceDiagram
    actor U as Buyer (User U)
    participant A as DocAsController
    participant D_A as DocA Model
    participant M as ProcurementMailer
    actor P as Approver P
    actor Q as Approver Q
    actor R as Approver R
    actor S as Approver S
    participant S_B as AutoCreateDocBService
    participant D_B as DocB Model

    U->>A: Create New Doc A (POST /doc_as)
    A->>D_A: Create DocA instance (with auto-generated EQ_ID, U_Date)
    D_A->>D_A: Set status: :pending_p_approval
    A->>M: document_submitted_to_approver(DocA, 'P')
    M-->>P: Email: "New Document Requires Your Approval"
    A-->>U: Redirect to Doc A show, notice

    P->>A: Approve Doc A (POST /doc_as/:id/approve)
    A->>D_A: Update p_remarks, p_date, status: :pending_q_approval
    A->>M: document_approved_status(DocA, U, "Approved by P")
    A->>M: document_submitted_to_approver(DocA, 'Q')
    M-->>U: Email: "Doc A Approved by P"
    M-->>Q: Email: "New Document Requires Your Approval"
    A-->>P: Redirect to Dashboard, notice

    Q->>A: Approve Doc A (POST /doc_as/:id/approve)
    A->>D_A: Update q_remarks, q_date, status: :pending_r_approval
    A->>M: document_approved_status(DocA, U, "Approved by Q")
    A->>M: document_submitted_to_approver(DocA, 'R')
    M-->>U: Email: "Doc A Approved by Q"
    M-->>R: Email: "New Document Requires Your Approval"
    A-->>Q: Redirect to Dashboard, notice

    R->>A: Approve Doc A (POST /doc_as/:id/approve)
    A->>D_A: Update r_remarks, r_date, status: :pending_s_approval
    A->>M: document_approved_status(DocA, U, "Approved by R")
    A->>M: document_submitted_to_approver(DocA, 'S')
    M-->>U: Email: "Doc A Approved by R"
    M-->>S: Email: "New Document Requires Your Approval"
    A-->>R: Redirect to Dashboard, notice

    S->>A: Approve Doc A (POST /doc_as/:id/approve)
    A->>D_A: Update s_remarks, s_date, status: :approved
    A->>M: document_approved_status(DocA, U, "Fully Approved - Document A Complete")
    M-->>U: Email: "Doc A Fully Approved"
    A->>S_B: new(DocA, current_user).call
    S_B->>D_B: Create DocB instance (pre-filled from DocA)
    S_B-->>A: Returns DocB
    A-->>S: Redirect to New Doc B page, notice
```